// Palestinian National Library - Enhanced Document Management System
// Integrated with Gemini AI and Advanced Features

class EnhancedDocumentManager {
    constructor() {
        this.currentUser = null;
        this.authToken = localStorage.getItem('authToken');
        this.uploadedFiles = [];
        this.currentTab = 'upload';
        this.isAdmin = false;
        this.init();
    }

    init() {
        console.log('Enhanced DocumentManager initializing with Gemini AI...');
        this.setupEventListeners();
        this.setupTabs();
        this.setupUploadArea();
        this.setupAuth();
        this.setupAssistant();
        this.setupTranslation();
        this.checkAuthStatus();
        this.setupPWASupport();
    }

    setupEventListeners() {
        // Tab navigation
        document.getElementById('tab-upload')?.addEventListener('click', () => this.showTab('upload'));
        document.getElementById('tab-reports')?.addEventListener('click', () => this.showTab('reports'));
        document.getElementById('tab-documents')?.addEventListener('click', () => this.showTab('documents'));
        document.getElementById('tab-assistant')?.addEventListener('click', () => this.showTab('assistant'));
        document.getElementById('tab-admin')?.addEventListener('click', () => this.showTab('admin'));

        // Authentication
        document.getElementById('login-modal-btn')?.addEventListener('click', () => this.showAuthModal());
        document.getElementById('close-auth-modal')?.addEventListener('click', () => this.hideAuthModal());
        document.getElementById('logout-btn')?.addEventListener('click', () => this.logout());
        document.getElementById('auth-form')?.addEventListener('submit', (e) => this.handleAuth(e));

        // Auth tabs
        document.getElementById('login-tab')?.addEventListener('click', () => this.switchAuthTab('login'));
        document.getElementById('register-tab')?.addEventListener('click', () => this.switchAuthTab('register'));

        // File upload
        document.getElementById('file-input')?.addEventListener('change', (e) => this.handleFileSelect(e));
        document.getElementById('upload-area')?.addEventListener('click', () => {
            document.getElementById('file-input')?.click();
        });

        // Assistant
        document.getElementById('ask-btn')?.addEventListener('click', () => this.askAssistant());
        document.getElementById('question-input')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.askAssistant();
        });

        // Quick questions
        document.querySelectorAll('.quick-question').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const question = e.target.getAttribute('data-question');
                document.getElementById('question-input').value = question;
                this.askAssistant();
            });
        });

        // Drag and drop
        this.setupDragAndDrop();
    }

    setupDragAndDrop() {
        const uploadArea = document.getElementById('upload-area');
        if (uploadArea) {
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('border-green-600', 'bg-green-50');
            });

            uploadArea.addEventListener('dragleave', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('border-green-600', 'bg-green-50');
            });

            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('border-green-600', 'bg-green-50');
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    this.handleFiles(files);
                }
            });
        }
    }

    setupTabs() {
        this.showTab('upload');
    }

    showTab(tabName) {
        // Hide all tabs
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.add('hidden');
        });

        // Remove active class from all buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active', 'bg-green-600', 'text-white');
            btn.classList.add('text-gray-600');
        });

        // Show selected tab
        const content = document.getElementById(`content-${tabName}`);
        const button = document.getElementById(`tab-${tabName}`);
        
        if (content) content.classList.remove('hidden');
        if (button) {
            button.classList.add('active', 'bg-green-600', 'text-white');
            button.classList.remove('text-gray-600');
        }

        this.currentTab = tabName;

        // Load specific content
        if (tabName === 'reports') {
            this.loadReports();
        } else if (tabName === 'documents') {
            this.loadUserDocuments();
        } else if (tabName === 'assistant') {
            this.initAssistant();
        } else if (tabName === 'translate') {
            this.initTranslate();
        } else if (tabName === 'admin') {
            this.loadAdminDashboard();
        }
    }

    setupUploadArea() {
        // Already handled in setupEventListeners
    }

    setupAuth() {
        // Already handled in setupEventListeners
    }

    setupAssistant() {
        // Assistant setup is handled in showTab method
    }

    // Translation functionality
    setupTranslation() {
        console.log('Setting up translation functionality...');
        
        // Add tab event listener
        document.getElementById('tab-translate')?.addEventListener('click', () => this.showTab('translate'));
        
        // Translation button
        document.getElementById('translate-btn')?.addEventListener('click', () => this.performTranslation());
        
        // Character counter
        document.getElementById('text-to-translate')?.addEventListener('input', (e) => {
            this.updateCharCount(e.target.value);
        });
        
        // Quick translation buttons
        document.querySelectorAll('.quick-translate').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const direction = e.target.getAttribute('data-direction');
                this.setQuickTranslation(direction);
            });
        });
        
        // Copy translation button
        document.getElementById('copy-translation')?.addEventListener('click', () => this.copyTranslation());
        
        // Download translation button  
        document.getElementById('download-translation')?.addEventListener('click', () => this.downloadTranslation());
        
        // Initialize translation history
        this.translationHistory = JSON.parse(localStorage.getItem('translationHistory') || '[]');
    }
    
    updateCharCount(text) {
        const charCount = document.getElementById('char-count');
        if (charCount) {
            charCount.textContent = `${text.length} حرف`;
        }
    }
    
    setQuickTranslation(direction) {
        const fromLang = document.getElementById('from-language');
        const toLang = document.getElementById('to-language');
        
        if (!fromLang || !toLang) return;
        
        switch(direction) {
            case 'ar-en':
                fromLang.value = 'العربية';
                toLang.value = 'الإنجليزية';
                break;
            case 'en-ar':
                fromLang.value = 'الإنجليزية';
                toLang.value = 'العربية';
                break;
            case 'ar-fr':
                fromLang.value = 'العربية';
                toLang.value = 'الفرنسية';
                break;
            case 'fr-ar':
                fromLang.value = 'الفرنسية';
                toLang.value = 'العربية';
                break;
        }
    }
    
    async performTranslation() {
        const textInput = document.getElementById('text-to-translate');
        const fromLang = document.getElementById('from-language');
        const toLang = document.getElementById('to-language');
        const contextInput = document.getElementById('translation-context');
        const translateBtn = document.getElementById('translate-btn');
        const output = document.getElementById('translation-output');
        
        if (!textInput || !fromLang || !toLang || !output) {
            console.error('Translation elements not found');
            return;
        }
        
        const text = textInput.value.trim();
        const fromLanguage = fromLang.value;
        const toLanguage = toLang.value;
        const context = contextInput?.value || '';
        
        if (!text) {
            this.showNotification('يرجى إدخال النص المراد ترجمته', 'warning');
            return;
        }
        
        if (fromLanguage === toLanguage) {
            this.showNotification('يرجى اختيار لغات مختلفة للترجمة', 'warning');
            return;
        }
        
        // Show loading state
        const originalBtnText = translateBtn.innerHTML;
        translateBtn.disabled = true;
        translateBtn.innerHTML = '<i class="fas fa-spinner fa-spin ml-2"></i> جاري الترجمة...';
        
        // Show loading in output
        output.innerHTML = `
            <div class="text-center py-12">
                <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
                <p class="text-gray-600">جاري الترجمة باستخدام Gemini AI...</p>
            </div>
        `;
        
        const startTime = Date.now();
        
        try {
            const response = await fetch('/api/translate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    text: text,
                    fromLanguage: fromLanguage,
                    toLanguage: toLanguage,
                    context: context
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.displayTranslationResult(result, Date.now() - startTime);
                this.addToTranslationHistory(text, result.translatedText, fromLanguage, toLanguage);
                this.currentTranslationId = result.downloadUrl?.split('/').pop();
            } else {
                this.showTranslationError(result.error);
            }
        } catch (error) {
            console.error('Translation error:', error);
            this.showTranslationError('حدث خطأ في الاتصال بخدمة الترجمة');
        }
        
        // Restore button state
        translateBtn.disabled = false;
        translateBtn.innerHTML = originalBtnText;
    }
    
    displayTranslationResult(result, timeMs) {
        const output = document.getElementById('translation-output');
        const details = document.getElementById('translation-details');
        const alternatives = document.getElementById('alternatives-section');
        const actions = document.getElementById('translation-actions');
        
        if (!output) return;
        
        // Main translation result
        output.innerHTML = `
            <div class="bg-white border rounded-lg p-4 min-h-[150px]">
                <div class="text-gray-800 text-lg leading-relaxed" style="direction: ${this.getTextDirection(result.toLanguage)};">
                    ${result.translatedText}
                </div>
            </div>
        `;
        
        // Show details
        if (details) {
            details.classList.remove('hidden');
            document.getElementById('confidence-score').textContent = `${result.confidence || 90}%`;
            document.getElementById('translation-time').textContent = `${(timeMs / 1000).toFixed(1)} ثانية`;
            document.getElementById('word-count').textContent = `${result.originalText.split(' ').length} كلمة`;
        }
        
        // Show alternatives if available
        if (alternatives && result.alternatives && result.alternatives.length > 0) {
            alternatives.classList.remove('hidden');
            const alternativesList = document.getElementById('alternatives-list');
            if (alternativesList) {
                alternativesList.innerHTML = result.alternatives.map((alt, index) => `
                    <div class="bg-white border rounded p-2 text-sm cursor-pointer hover:bg-yellow-100" 
                         onclick="documentManager.selectAlternative('${alt.replace(/'/g, "\\'")}')">
                        <strong>${index + 1}.</strong> ${alt}
                    </div>
                `).join('');
            }
        }
        
        // Show action buttons
        if (actions) {
            actions.classList.remove('hidden');
        }
        
        this.showNotification('تمت الترجمة بنجاح!', 'success');
    }
    
    showTranslationError(error) {
        const output = document.getElementById('translation-output');
        if (output) {
            output.innerHTML = `
                <div class="text-center py-12">
                    <i class="fas fa-exclamation-triangle text-red-500 text-4xl mb-4"></i>
                    <p class="text-red-600 mb-2">حدث خطأ في الترجمة</p>
                    <p class="text-sm text-gray-500">${error}</p>
                </div>
            `;
        }
        this.showNotification('فشلت عملية الترجمة', 'error');
    }
    
    getTextDirection(language) {
        const rtlLanguages = ['العربية', 'العبرية', 'الفارسية'];
        return rtlLanguages.includes(language) ? 'rtl' : 'ltr';
    }
    
    selectAlternative(alternative) {
        const output = document.getElementById('translation-output');
        if (output) {
            const textDiv = output.querySelector('.text-gray-800');
            if (textDiv) {
                textDiv.textContent = alternative;
                this.showNotification('تم اختيار الترجمة البديلة', 'info');
            }
        }
    }
    
    copyTranslation() {
        const output = document.getElementById('translation-output');
        if (output) {
            const textDiv = output.querySelector('.text-gray-800');
            if (textDiv) {
                const text = textDiv.textContent;
                navigator.clipboard.writeText(text).then(() => {
                    this.showNotification('تم نسخ الترجمة', 'success');
                }).catch(() => {
                    this.showNotification('فشل في نسخ النص', 'error');
                });
            }
        }
    }
    
    downloadTranslation() {
        if (this.currentTranslationId) {
            const downloadUrl = `/api/download/translation/${this.currentTranslationId}`;
            window.open(downloadUrl, '_blank');
            this.showNotification('بدء تحميل الترجمة', 'info');
        } else {
            this.showNotification('لا توجد ترجمة للتحميل', 'warning');
        }
    }
    
    addToTranslationHistory(original, translated, fromLang, toLang) {
        const historyItem = {
            id: Date.now(),
            original: original.substring(0, 50) + (original.length > 50 ? '...' : ''),
            translated: translated.substring(0, 50) + (translated.length > 50 ? '...' : ''),
            fromLanguage: fromLang,
            toLanguage: toLang,
            timestamp: new Date().toISOString()
        };
        
        this.translationHistory.unshift(historyItem);
        
        // Keep only last 10 translations
        if (this.translationHistory.length > 10) {
            this.translationHistory = this.translationHistory.slice(0, 10);
        }
        
        localStorage.setItem('translationHistory', JSON.stringify(this.translationHistory));
        this.updateTranslationHistory();
    }
    
    updateTranslationHistory() {
        const historyContainer = document.getElementById('translation-history');
        if (!historyContainer) return;
        
        if (this.translationHistory.length === 0) {
            historyContainer.innerHTML = '<p class="text-gray-500 text-center py-4">لا توجد ترجمات سابقة</p>';
            return;
        }
        
        historyContainer.innerHTML = this.translationHistory.map(item => `
            <div class="bg-white border rounded-lg p-3 hover:bg-gray-50 cursor-pointer" 
                 onclick="documentManager.loadHistoryItem('${item.id}')">
                <div class="flex justify-between items-start">
                    <div class="flex-1">
                        <div class="text-sm font-semibold text-gray-800 mb-1">
                            ${item.fromLanguage} → ${item.toLanguage}
                        </div>
                        <div class="text-sm text-gray-600 mb-1">${item.original}</div>
                        <div class="text-sm text-green-600">${item.translated}</div>
                    </div>
                    <div class="text-xs text-gray-400">
                        ${new Date(item.timestamp).toLocaleDateString('ar-SA')}
                    </div>
                </div>
            </div>
        `).join('');
    }
    
    loadHistoryItem(itemId) {
        const item = this.translationHistory.find(h => h.id == itemId);
        if (!item) return;
        
        // Switch to translate tab
        this.showTab('translate');
        
        // Set language selections
        const fromLang = document.getElementById('from-language');
        const toLang = document.getElementById('to-language');
        
        if (fromLang) fromLang.value = item.fromLanguage;
        if (toLang) toLang.value = item.toLanguage;
        
        this.showNotification('تم تحميل الترجمة من السجل', 'info');
    }

    checkAuthStatus() {
        if (this.authToken) {
            const userData = localStorage.getItem('userData');
            if (userData) {
                this.currentUser = JSON.parse(userData);
                this.isAdmin = this.currentUser.role === 'admin';
                this.updateAuthUI();
            }
        }
    }

    showAuthModal() {
        document.getElementById('auth-modal')?.classList.remove('hidden');
    }

    hideAuthModal() {
        document.getElementById('auth-modal')?.classList.add('hidden');
    }

    switchAuthTab(tab) {
        const loginTab = document.getElementById('login-tab');
        const registerTab = document.getElementById('register-tab');
        const registerFields = document.getElementById('register-fields');
        const authSubmit = document.getElementById('auth-submit');
        const authModalTitle = document.getElementById('auth-modal-title');

        if (tab === 'login') {
            loginTab?.classList.add('active');
            registerTab?.classList.remove('active');
            registerFields?.classList.add('hidden');
            if (authSubmit) authSubmit.textContent = 'تسجيل الدخول';
            if (authModalTitle) authModalTitle.textContent = 'تسجيل الدخول';
        } else {
            registerTab?.classList.add('active');
            loginTab?.classList.remove('active');
            registerFields?.classList.remove('hidden');
            if (authSubmit) authSubmit.textContent = 'إنشاء حساب';
            if (authModalTitle) authModalTitle.textContent = 'إنشاء حساب جديد';
        }
    }

    async handleAuth(e) {
        e.preventDefault();
        
        const email = document.getElementById('auth-email')?.value;
        const password = document.getElementById('auth-password')?.value;
        const name = document.getElementById('register-name')?.value;
        const isLogin = document.getElementById('login-tab')?.classList.contains('active');

        if (!email || !password) {
            this.showNotification('يرجى ملء جميع الحقول المطلوبة', 'error');
            return;
        }

        try {
            const endpoint = isLogin ? '/api/login' : '/api/register';
            const body = isLogin ? { email, password } : { name, email, password };

            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });

            const result = await response.json();

            if (result.success) {
                this.authToken = result.token;
                this.currentUser = result.user;
                this.isAdmin = result.user.role === 'admin';
                localStorage.setItem('authToken', this.authToken);
                localStorage.setItem('userData', JSON.stringify(this.currentUser));
                
                this.updateAuthUI();
                this.hideAuthModal();
                this.showNotification(result.message, 'success');
                
                // Clear form
                document.getElementById('auth-form')?.reset();
                
                // Show admin tab if user is admin
                if (this.isAdmin) {
                    document.getElementById('tab-admin')?.classList.remove('hidden');
                }
            } else {
                this.showNotification(result.error, 'error');
            }
        } catch (error) {
            console.error('Auth error:', error);
            this.showNotification('حدث خطأ في الاتصال', 'error');
        }
    }

    logout() {
        this.authToken = null;
        this.currentUser = null;
        this.isAdmin = false;
        localStorage.removeItem('authToken');
        localStorage.removeItem('userData');
        
        this.updateAuthUI();
        this.showNotification('تم تسجيل الخروج بنجاح', 'info');
        
        // Hide admin tab
        document.getElementById('tab-admin')?.classList.add('hidden');
        
        if (this.currentTab === 'documents' || this.currentTab === 'admin') {
            this.showTab('upload');
        }
    }

    updateAuthUI() {
        const authSection = document.getElementById('auth-section');
        const loginSection = document.getElementById('login-section');
        const userName = document.getElementById('user-name');
        const userRole = document.getElementById('user-role');
        
        if (this.currentUser) {
            authSection?.classList.remove('hidden');
            loginSection?.classList.add('hidden');
            if (userName) userName.textContent = this.currentUser.name || 'مستخدم';
            if (userRole) {
                userRole.textContent = this.isAdmin ? 'مدير' : 'مستخدم';
                userRole.className = this.isAdmin ? 
                    'text-xs bg-red-100 text-red-800 px-2 py-1 rounded' : 
                    'text-xs bg-green-100 text-green-800 px-2 py-1 rounded';
            }
        } else {
            authSection?.classList.add('hidden');
            loginSection?.classList.remove('hidden');
        }
    }

    handleFileSelect(e) {
        const files = e.target.files;
        if (files.length > 0) {
            this.handleFiles(files);
        }
    }

    async handleFiles(files) {
        this.uploadedFiles = [];
        
        for (const file of files) {
            // Validate file
            if (!this.validateFile(file)) {
                continue;
            }
            
            // Convert to base64
            const base64 = await this.fileToBase64(file);
            this.uploadedFiles.push({
                file: file,
                base64: base64,
                name: file.name,
                size: file.size,
                type: file.type
            });
        }
        
        if (this.uploadedFiles.length > 0) {
            this.showProcessingOptions();
        }
    }

    validateFile(file) {
        const maxSize = 10 * 1024 * 1024; // 10MB
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/tiff', 'application/pdf'];
        
        if (file.size > maxSize) {
            this.showNotification(`الملف ${file.name} كبير جداً (الحد الأقصى 10MB)`, 'error');
            return false;
        }
        
        if (!allowedTypes.includes(file.type)) {
            this.showNotification(`نوع الملف ${file.type} غير مدعوم`, 'error');
            return false;
        }
        
        return true;
    }

    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    showProcessingOptions() {
        const resultsSection = document.getElementById('results-section');
        const resultsContent = document.getElementById('results-content');
        
        if (!resultsSection || !resultsContent) return;
        
        resultsSection.classList.remove('hidden');
        
        let html = `
            <div class="mb-6">
                <h4 class="text-lg font-bold text-gray-800 mb-4">الملفات المرفوعة:</h4>
                <div class="space-y-2">
        `;
        
        this.uploadedFiles.forEach((fileData, index) => {
            html += `
                <div class="flex items-center justify-between bg-gray-50 p-3 rounded">
                    <div class="flex items-center">
                        <i class="fas fa-file-image text-green-600 ml-2"></i>
                        <span class="font-semibold">${fileData.name}</span>
                        <span class="text-sm text-gray-500 mr-2">(${this.formatFileSize(fileData.size)})</span>
                    </div>
                </div>
            `;
        });
        
        html += `
                </div>
            </div>
            
            <div class="grid md:grid-cols-3 gap-6 mb-8">
                <div class="bg-green-50 border border-green-200 rounded-lg p-6">
                    <h4 class="font-bold text-green-800 mb-4">
                        <i class="fas fa-magic ml-2"></i>
                        ترميم بـ Gemini AI
                    </h4>
                    <p class="text-sm text-green-700 mb-4">تحليل وترميم متقدم باستخدام تقنية Gemini Vision</p>
                    
                    <div class="space-y-2 mb-4">
                        <label class="block">
                            <input type="radio" name="restore-mode" value="preserve" class="ml-2" checked>
                            <span class="text-sm">الحفاظ على الطابع التاريخي</span>
                        </label>
                        <label class="block">
                            <input type="radio" name="restore-mode" value="cleanup" class="ml-2">
                            <span class="text-sm">تنظيف كامل</span>
                        </label>
                        <label class="block">
                            <input type="radio" name="restore-mode" value="enhance" class="ml-2">
                            <span class="text-sm">تحسين الوضوح</span>
                        </label>
                    </div>
                    
                    <button onclick="documentManager.processRestore()" class="w-full bg-green-600 text-white py-2 px-4 rounded font-semibold hover:bg-green-700">
                        <i class="fas fa-play ml-2"></i>
                        بدء الترميم
                    </button>
                </div>
                
                <div class="bg-red-50 border border-red-200 rounded-lg p-6">
                    <h4 class="font-bold text-red-800 mb-4">
                        <i class="fas fa-language ml-2"></i>
                        استخراج النص
                    </h4>
                    <p class="text-sm text-red-700 mb-4">استخراج النص باستخدام Gemini Vision API</p>
                    
                    <div class="mb-4">
                        <select id="ocr-languages" class="w-full p-2 border rounded text-sm">
                            <option value="auto">كشف تلقائي للغة</option>
                            <option value="ar">العربية</option>
                            <option value="en">الإنجليزية</option>
                            <option value="fr">الفرنسية</option>
                            <option value="tr">التركية</option>
                            <option value="multi">متعدد اللغات</option>
                        </select>
                    </div>
                    
                    <button onclick="documentManager.processOCR()" class="w-full bg-red-600 text-white py-2 px-4 rounded font-semibold hover:bg-red-700">
                        <i class="fas fa-play ml-2"></i>
                        استخراج النص
                    </button>
                </div>
                
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-6">
                    <h4 class="font-bold text-blue-800 mb-4">
                        <i class="fas fa-brain ml-2"></i>
                        تصنيف ذكي
                    </h4>
                    <p class="text-sm text-blue-700 mb-4">تصنيف وتحليل محتوى بـ Gemini AI</p>
                    
                    <div class="text-xs text-blue-600 mb-4">
                        <div>📁 تاريخية</div>
                        <div>⚖️ قانونية</div>
                        <div>📚 تعليمية</div>
                        <div>📄 إدارية</div>
                        <div>👤 شخصية</div>
                    </div>
                    
                    <button onclick="documentManager.processClassify()" class="w-full bg-blue-600 text-white py-2 px-4 rounded font-semibold hover:bg-blue-700">
                        <i class="fas fa-play ml-2"></i>
                        تصنيف الوثيقة
                    </button>
                </div>
            </div>
        `;
        
        resultsContent.innerHTML = html;
    }

    async processRestore() {
        if (this.uploadedFiles.length === 0) {
            this.showNotification('لا توجد ملفات لمعالجتها', 'error');
            return;
        }

        const mode = document.querySelector('input[name="restore-mode"]:checked')?.value || 'preserve';
        
        this.showProcessingIndicator('ترميم', 'جاري ترميم الوثائق باستخدام Gemini AI...');

        try {
            for (const fileData of this.uploadedFiles) {
                const response = await fetch('/api/restore', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        image: fileData.base64,
                        mode: mode
                    })
                });

                const result = await response.json();

                if (result.success) {
                    this.displayRestoreResult(result, fileData.name);
                } else {
                    this.showNotification(`خطأ في ترميم ${fileData.name}: ${result.error}`, 'error');
                }
            }
        } catch (error) {
            console.error('Restore error:', error);
            this.showNotification('حدث خطأ في عملية الترميم', 'error');
        }

        this.hideProcessingIndicator();
    }

    async processOCR() {
        if (this.uploadedFiles.length === 0) {
            this.showNotification('لا توجد ملفات لمعالجتها', 'error');
            return;
        }

        const languages = document.getElementById('ocr-languages')?.value || 'auto';
        
        this.showProcessingIndicator('OCR', 'جاري استخراج النص باستخدام Gemini Vision...');

        try {
            for (const fileData of this.uploadedFiles) {
                const response = await fetch('/api/ocr', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        image: fileData.base64,
                        languages: [languages]
                    })
                });

                const result = await response.json();

                if (result.success) {
                    this.displayOCRResult(result, fileData.name);
                } else {
                    this.showNotification(`خطأ في استخراج النص من ${fileData.name}: ${result.error}`, 'error');
                }
            }
        } catch (error) {
            console.error('OCR error:', error);
            this.showNotification('حدث خطأ في استخراج النص', 'error');
        }

        this.hideProcessingIndicator();
    }

    async processClassify() {
        if (this.uploadedFiles.length === 0) {
            this.showNotification('لا توجد ملفات لمعالجتها', 'error');
            return;
        }
        
        this.showProcessingIndicator('تصنيف', 'جاري تصنيف الوثائق باستخدام Gemini AI...');

        try {
            for (const fileData of this.uploadedFiles) {
                const response = await fetch('/api/classify', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        image: fileData.base64
                    })
                });

                const result = await response.json();

                if (result.success) {
                    this.displayClassifyResult(result, fileData.name);
                } else {
                    this.showNotification(`خطأ في تصنيف ${fileData.name}: ${result.error}`, 'error');
                }
            }
        } catch (error) {
            console.error('Classify error:', error);
            this.showNotification('حدث خطأ في تصنيف الوثائق', 'error');
        }

        this.hideProcessingIndicator();
    }

    displayRestoreResult(result, fileName) {
        const resultsContent = document.getElementById('results-content');
        if (!resultsContent) return;

        const resultHtml = `
            <div class="border-t pt-6 mt-6">
                <h4 class="text-lg font-bold text-green-800 mb-4">
                    <i class="fas fa-magic ml-2"></i>
                    نتيجة ترميم بـ Gemini AI: ${fileName}
                </h4>
                
                <div class="bg-green-50 rounded-lg p-4 mb-4">
                    <h5 class="font-semibold text-green-800 mb-2">تحليل Gemini AI:</h5>
                    <p class="text-green-700 text-sm">${result.analysis || 'تم تحليل الوثيقة وتحسينها بنجاح'}</p>
                </div>
                
                <div class="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <h5 class="font-semibold text-gray-700 mb-2">الصورة الأصلية:</h5>
                        <div class="border rounded-lg p-4 bg-gray-50">
                            <img src="${result.originalImage}" alt="الصورة الأصلية" class="w-full max-w-sm mx-auto rounded">
                        </div>
                    </div>
                    
                    <div>
                        <h5 class="font-semibold text-gray-700 mb-2">الصورة المرممة:</h5>
                        <div class="border rounded-lg p-4 bg-green-50">
                            <img src="${result.restoredImage}" alt="الصورة المرممة" class="w-full max-w-sm mx-auto rounded">
                        </div>
                    </div>
                </div>
                
                <div class="bg-gray-50 rounded-lg p-4 mb-4">
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <strong>نمط الترميم:</strong> ${this.getModeLabel(result.mode)}
                        </div>
                        <div>
                            <strong>تاريخ المعالجة:</strong> ${new Date(result.processedAt).toLocaleString('ar-SA')}
                        </div>
                    </div>
                </div>
                
                <div class="flex flex-wrap gap-3">
                    <button onclick="documentManager.downloadFromUrl('${result.restoredImage}', 'restored_${fileName}')" class="download-btn">
                        <i class="fas fa-download"></i>
                        تحميل المرممة
                    </button>
                    <button onclick="documentManager.downloadFromUrl('${result.originalImage}', 'original_${fileName}')" class="download-btn bg-gray-600 hover:bg-gray-700">
                        <i class="fas fa-file"></i>
                        تحميل الأصلية
                    </button>
                </div>
            </div>
        `;
        
        resultsContent.insertAdjacentHTML('beforeend', resultHtml);
    }

    displayOCRResult(result, fileName) {
        const resultsContent = document.getElementById('results-content');
        if (!resultsContent) return;

        const resultHtml = `
            <div class="border-t pt-6 mt-6">
                <h4 class="text-lg font-bold text-red-800 mb-4">
                    <i class="fas fa-language ml-2"></i>
                    نتيجة استخراج النص بـ Gemini Vision: ${fileName}
                </h4>
                
                <div class="bg-gray-50 rounded-lg p-4 mb-4">
                    <div class="grid md:grid-cols-3 gap-4 mb-4">
                        <div>
                            <strong>اللغة المكتشفة:</strong> ${result.detectedLanguage}
                        </div>
                        <div>
                            <strong>دقة التعرف:</strong> ${(result.confidence * 100).toFixed(1)}%
                        </div>
                        <div>
                            <strong>تاريخ الاستخراج:</strong> ${new Date(result.processedAt).toLocaleString('ar-SA')}
                        </div>
                    </div>
                </div>
                
                <div class="bg-white border rounded-lg p-4 mb-4">
                    <h5 class="font-semibold text-gray-700 mb-3">النص المستخرج:</h5>
                    <div class="bg-gray-50 rounded p-3 font-mono text-sm whitespace-pre-wrap max-h-64 overflow-y-auto" dir="auto">
${result.extractedText}
                    </div>
                </div>
                
                <div class="flex flex-wrap gap-3">
                    <button onclick="documentManager.downloadText('${result.extractedText.replace(/'/g, "\\'")}', '${fileName}')" class="download-btn">
                        <i class="fas fa-download"></i>
                        تحميل النص (TXT)
                    </button>
                    <button onclick="documentManager.copyToClipboard('${result.extractedText.replace(/'/g, "\\\'")}')" class="download-btn bg-blue-600 hover:bg-blue-700">
                        <i class="fas fa-copy"></i>
                        نسخ النص
                    </button>
                    <button onclick="documentManager.downloadFromUrl('${result.originalImage}', 'original_${fileName}')" class="download-btn bg-gray-600 hover:bg-gray-700">
                        <i class="fas fa-file"></i>
                        تحميل الأصلية
                    </button>
                </div>
            </div>
        `;
        
        resultsContent.insertAdjacentHTML('beforeend', resultHtml);
    }

    displayClassifyResult(result, fileName) {
        const resultsContent = document.getElementById('results-content');
        if (!resultsContent) return;

        const resultHtml = `
            <div class="border-t pt-6 mt-6">
                <h4 class="text-lg font-bold text-blue-800 mb-4">
                    <i class="fas fa-brain ml-2"></i>
                    نتيجة تصنيف بـ Gemini AI: ${fileName}
                </h4>
                
                ${result.analysis ? `
                <div class="bg-blue-50 rounded-lg p-4 mb-4">
                    <h5 class="font-semibold text-blue-800 mb-2">تحليل Gemini AI:</h5>
                    <p class="text-blue-700 text-sm">${result.analysis}</p>
                </div>
                ` : ''}
                
                <div class="grid md:grid-cols-2 gap-6">
                    <div class="bg-blue-50 rounded-lg p-4">
                        <h5 class="font-semibold text-blue-800 mb-3">تفاصيل التصنيف:</h5>
                        <div class="space-y-2">
                            <div><strong>الفئة الرئيسية:</strong> ${result.category}</div>
                            <div><strong>الفئة الفرعية:</strong> ${result.subcategory}</div>
                            <div><strong>دقة التصنيف:</strong> ${(result.confidence * 100).toFixed(1)}%</div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-50 rounded-lg p-4">
                        <h5 class="font-semibold text-gray-700 mb-3">الكلمات المفتاحية:</h5>
                        <div class="flex flex-wrap gap-2">
                            ${result.keywords.map(keyword => `<span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">${keyword}</span>`).join('')}
                        </div>
                        
                        <div class="mt-3">
                            <h6 class="font-semibold text-gray-600 mb-2">العلامات:</h6>
                            <div class="flex flex-wrap gap-2">
                                ${result.tags.map(tag => `<span class="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">${tag}</span>`).join('')}
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-4 bg-gray-50 rounded-lg p-3">
                    <small class="text-gray-600">تم التصنيف في: ${new Date(result.processedAt).toLocaleString('ar-SA')}</small>
                </div>
            </div>
        `;
        
        resultsContent.insertAdjacentHTML('beforeend', resultHtml);
    }

    downloadText(text, fileName) {
        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `extracted_text_${fileName}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showNotification('تم تحميل الملف بنجاح', 'success');
    }

    downloadFromUrl(dataUrl, fileName) {
        const a = document.createElement('a');
        a.href = dataUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        this.showNotification('تم بدء التحميل', 'success');
    }

    async copyToClipboard(text) {
        try {
            await navigator.clipboard.writeText(text);
            this.showNotification('تم نسخ النص إلى الحافظة', 'success');
        } catch (error) {
            console.error('Copy failed:', error);
            this.showNotification('فشل في نسخ النص', 'error');
        }
    }

    getModeLabel(mode) {
        const labels = {
            'preserve': 'الحفاظ على الطابع التاريخي',
            'cleanup': 'تنظيف كامل',
            'enhance': 'تحسين الوضوح'
        };
        return labels[mode] || mode;
    }

    showProcessingIndicator(type, message) {
        const resultsContent = document.getElementById('results-content');
        if (!resultsContent) return;

        const indicator = `
            <div id="processing-indicator" class="text-center py-8 border-t mt-6">
                <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
                <h4 class="text-lg font-bold text-gray-800 mb-2">جاري ${type}...</h4>
                <p class="text-gray-600">${message}</p>
                <div class="mt-4 bg-blue-50 rounded-lg p-3">
                    <p class="text-blue-700 text-sm">
                        <i class="fas fa-robot ml-1"></i>
                        يتم استخدام تقنية Gemini AI للحصول على أفضل النتائج
                    </p>
                </div>
            </div>
        `;
        
        resultsContent.insertAdjacentHTML('beforeend', indicator);
    }

    hideProcessingIndicator() {
        const indicator = document.getElementById('processing-indicator');
        if (indicator) {
            indicator.remove();
        }
    }

    async loadReports() {
        const reportsLoading = document.getElementById('reports-loading');
        const reportsContent = document.getElementById('reports-content');
        
        if (reportsLoading) reportsLoading.classList.remove('hidden');
        if (reportsContent) reportsContent.classList.add('hidden');

        try {
            const response = await fetch('/api/reports/statistics');
            const result = await response.json();

            if (result.success) {
                this.displayReports(result.statistics);
            } else {
                this.showNotification('فشل في تحميل التقارير', 'error');
            }
        } catch (error) {
            console.error('Reports error:', error);
            this.showNotification('خطأ في تحميل البيانات', 'error');
        }

        if (reportsLoading) reportsLoading.classList.add('hidden');
        if (reportsContent) reportsContent.classList.remove('hidden');
    }

    displayReports(statistics) {
        const reportsContent = document.getElementById('reports-content');
        if (!reportsContent) return;

        const html = `
            <div class="grid md:grid-cols-4 gap-6 mb-8">
                <div class="stat-card rounded-lg p-6 text-center">
                    <div class="text-3xl font-bold text-green-600">${statistics.totalDocuments}</div>
                    <div class="text-sm text-green-700">إجمالي الوثائق</div>
                </div>
                <div class="stat-card rounded-lg p-6 text-center">
                    <div class="text-3xl font-bold text-blue-600">${statistics.processedToday}</div>
                    <div class="text-sm text-blue-700">معالج اليوم</div>
                </div>
                <div class="stat-card rounded-lg p-6 text-center">
                    <div class="text-3xl font-bold text-purple-600">${statistics.totalUsers}</div>
                    <div class="text-sm text-purple-700">إجمالي المستخدمين</div>
                </div>
                <div class="stat-card rounded-lg p-6 text-center">
                    <div class="text-3xl font-bold text-orange-600">${statistics.activeUsers}</div>
                    <div class="text-sm text-orange-700">نشط حالياً</div>
                </div>
            </div>

            <div class="grid md:grid-cols-2 gap-8 mb-8">
                <div class="bg-white border rounded-lg p-6">
                    <h4 class="text-lg font-bold text-gray-800 mb-4">توزيع الوثائق حسب الفئة</h4>
                    <div class="space-y-3">
                        ${Object.entries(statistics.documentsByCategory).map(([category, count]) => `
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">${category}</span>
                                <div class="flex items-center">
                                    <div class="bg-green-200 rounded-full h-2 w-20 ml-3">
                                        <div class="bg-green-600 h-2 rounded-full" style="width: ${(count / Math.max(...Object.values(statistics.documentsByCategory)) * 100)}%"></div>
                                    </div>
                                    <span class="font-semibold text-green-600">${count}</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <div class="bg-white border rounded-lg p-6">
                    <h4 class="text-lg font-bold text-gray-800 mb-4">توزيع اللغات</h4>
                    <div class="space-y-3">
                        ${Object.entries(statistics.languageDistribution).map(([language, percentage]) => `
                            <div class="flex justify-between items-center">
                                <span class="text-gray-700">${language}</span>
                                <div class="flex items-center">
                                    <div class="bg-blue-200 rounded-full h-2 w-20 ml-3">
                                        <div class="bg-blue-600 h-2 rounded-full" style="width: ${percentage}%"></div>
                                    </div>
                                    <span class="font-semibold text-blue-600">${percentage}%</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>

            ${statistics.recentProcessing && statistics.recentProcessing.length > 0 ? `
            <div class="bg-white border rounded-lg p-6">
                <h4 class="text-lg font-bold text-gray-800 mb-4">آخر العمليات المعالجة</h4>
                <div class="space-y-2">
                    ${statistics.recentProcessing.map(item => `
                        <div class="flex justify-between items-center p-2 hover:bg-gray-50 rounded">
                            <div class="flex items-center">
                                <span class="text-sm font-semibold text-gray-700">${item.type}</span>
                                <span class="text-xs text-gray-500 mr-2">${new Date(item.timestamp).toLocaleString('ar-SA')}</span>
                            </div>
                            <span class="text-xs px-2 py-1 rounded ${item.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                                ${item.success ? 'نجح' : 'فشل'}
                            </span>
                        </div>
                    `).join('')}
                </div>
            </div>
            ` : ''}

            <div class="mt-8 bg-gray-50 rounded-lg p-4">
                <small class="text-gray-600">آخر تحديث: ${new Date().toLocaleString('ar-SA')}</small>
            </div>
        `;

        reportsContent.innerHTML = html;
    }

    loadUserDocuments() {
        const documentsAuthRequired = document.getElementById('documents-auth-required');
        const documentsContent = document.getElementById('documents-content');
        
        if (!this.currentUser) {
            if (documentsAuthRequired) documentsAuthRequired.classList.remove('hidden');
            if (documentsContent) documentsContent.classList.add('hidden');
            return;
        }

        if (documentsAuthRequired) documentsAuthRequired.classList.add('hidden');
        if (documentsContent) {
            documentsContent.classList.remove('hidden');
            documentsContent.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-folder-open text-gray-400 text-4xl mb-4"></i>
                    <p class="text-gray-600 mb-4">لا توجد وثائق محفوظة بعد</p>
                    <p class="text-sm text-gray-500">ابدأ برفع وثائق لحفظها في حسابك</p>
                </div>
            `;
        }
    }

    initAssistant() {
        // Assistant initialization is handled when tab is shown
        console.log('Assistant initialized');
    }

    initTranslate() {
        console.log('Translation tab initialized');
        
        // Load and display translation history
        this.updateTranslationHistory();
        
        // Initialize character counter
        const textInput = document.getElementById('text-to-translate');
        if (textInput) {
            this.updateCharCount(textInput.value);
        }
        
        // Reset translation output
        const output = document.getElementById('translation-output');
        if (output) {
            output.innerHTML = `
                <div class="text-center text-gray-500 py-12">
                    <i class="fas fa-language text-4xl mb-4 text-green-500"></i>
                    <p>أدخل النص واضغط "ترجم الآن" لبدء الترجمة</p>
                </div>
            `;
        }
        
        // Hide details and alternatives
        const details = document.getElementById('translation-details');
        const alternatives = document.getElementById('alternatives-section');
        const actions = document.getElementById('translation-actions');
        
        if (details) details.classList.add('hidden');
        if (alternatives) alternatives.classList.add('hidden');
        if (actions) actions.classList.add('hidden');
    }

    async askAssistant() {
        const questionInput = document.getElementById('question-input');
        const chatContainer = document.getElementById('chat-container');
        const askBtn = document.getElementById('ask-btn');
        
        if (!questionInput || !chatContainer) return;
        
        const question = questionInput.value.trim();
        if (!question) {
            this.showNotification('يرجى كتابة سؤال', 'warning');
            return;
        }
        
        // Add user question to chat
        this.addMessageToChat('user', question);
        
        // Clear input and disable button
        questionInput.value = '';
        askBtn.disabled = true;
        askBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        
        // Add thinking indicator
        this.addMessageToChat('assistant', '🤔 جاري التفكير...', true);
        
        try {
            const response = await fetch('/api/assistant', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ question: question })
            });
            
            const result = await response.json();
            
            // Remove thinking indicator
            this.removeThinkingIndicator();
            
            if (result.success) {
                this.addMessageToChat('assistant', result.answer);
                
                // Add suggestions if available
                if (result.suggestions && result.suggestions.length > 0) {
                    this.addSuggestionsToChat(result.suggestions);
                }
            } else {
                this.addMessageToChat('assistant', 'عذراً، حدث خطأ في المساعد الذكي. يرجى المحاولة مرة أخرى.');
            }
        } catch (error) {
            console.error('Assistant error:', error);
            this.removeThinkingIndicator();
            this.addMessageToChat('assistant', 'عذراً، لا يمكنني الإجابة في الوقت الحالي. يرجى المحاولة لاحقاً.');
        }
        
        // Re-enable button
        askBtn.disabled = false;
        askBtn.innerHTML = '<i class="fas fa-paper-plane"></i>';
    }

    addMessageToChat(sender, message, isThinking = false) {
        const chatContainer = document.getElementById('chat-container');
        if (!chatContainer) return;
        
        // Clear initial message if exists
        const initialMessage = chatContainer.querySelector('.text-center');
        if (initialMessage) {
            initialMessage.remove();
        }
        
        const messageDiv = document.createElement('div');
        messageDiv.className = `mb-3 ${isThinking ? 'thinking-message' : ''}`;
        
        const isUser = sender === 'user';
        messageDiv.innerHTML = `
            <div class="flex ${isUser ? 'justify-end' : 'justify-start'}">
                <div class="max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    isUser ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800'
                }">
                    ${!isUser ? '<i class="fas fa-robot text-green-600 ml-1"></i>' : ''}
                    <span class="text-sm">${message}</span>
                </div>
            </div>
        `;
        
        chatContainer.appendChild(messageDiv);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    addSuggestionsToChat(suggestions) {
        const chatContainer = document.getElementById('chat-container');
        if (!chatContainer) return;
        
        const suggestionsDiv = document.createElement('div');
        suggestionsDiv.className = 'mb-3';
        suggestionsDiv.innerHTML = `
            <div class="flex justify-start">
                <div class="bg-blue-50 border border-blue-200 rounded-lg p-3 max-w-md">
                    <p class="text-xs text-blue-600 mb-2">اقتراحات أخرى:</p>
                    <div class="space-y-1">
                        ${suggestions.map(suggestion => `
                            <button class="suggestion-btn text-right w-full text-xs text-blue-700 hover:text-blue-900 p-1 hover:bg-blue-100 rounded" 
                                    data-question="${suggestion}">
                                • ${suggestion}
                            </button>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
        
        chatContainer.appendChild(suggestionsDiv);
        
        // Add event listeners to suggestion buttons
        suggestionsDiv.querySelectorAll('.suggestion-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const question = e.target.getAttribute('data-question');
                document.getElementById('question-input').value = question;
                this.askAssistant();
            });
        });
        
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    removeThinkingIndicator() {
        const thinkingMessage = document.querySelector('.thinking-message');
        if (thinkingMessage) {
            thinkingMessage.remove();
        }
    }

    async loadAdminDashboard() {
        if (!this.isAdmin) {
            this.showNotification('غير مصرح بالوصول لوحة التحكم', 'error');
            return;
        }
        
        const adminContent = document.getElementById('content-admin');
        if (!adminContent) return;
        
        adminContent.innerHTML = `
            <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                <div class="bg-gradient-to-r from-green-600 to-red-600 text-white p-6">
                    <h2 class="text-2xl font-bold mb-2">
                        <i class="fas fa-tachometer-alt ml-2"></i>
                        لوحة التحكم الإدارية
                    </h2>
                    <p>إدارة شاملة لنظام المكتبة الوطنية الفلسطينية</p>
                </div>
                
                <div class="p-6">
                    <!-- Admin navigation -->
                    <div class="flex flex-wrap space-x-2 rtl:space-x-reverse mb-6 bg-gray-50 rounded-lg p-2">
                        <button id="admin-tab-dashboard" class="admin-tab-btn active px-4 py-2 rounded bg-green-600 text-white font-semibold">
                            <i class="fas fa-chart-line ml-1"></i> لوحة المعلومات
                        </button>
                        <button id="admin-tab-users" class="admin-tab-btn px-4 py-2 rounded text-gray-600 hover:bg-gray-200">
                            <i class="fas fa-users ml-1"></i> المستخدمين
                        </button>
                        <button id="admin-tab-documents" class="admin-tab-btn px-4 py-2 rounded text-gray-600 hover:bg-gray-200">
                            <i class="fas fa-file-alt ml-1"></i> الوثائق
                        </button>
                        <button id="admin-tab-analytics" class="admin-tab-btn px-4 py-2 rounded text-gray-600 hover:bg-gray-200">
                            <i class="fas fa-chart-bar ml-1"></i> التحليلات
                        </button>
                    </div>
                    
                    <!-- Admin content area -->
                    <div id="admin-dashboard-content">
                        <div class="text-center py-8">
                            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
                            <p class="text-gray-600">جاري تحميل البيانات الإدارية...</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Setup admin tab listeners
        this.setupAdminTabs();
        
        // Load dashboard data
        await this.loadAdminDashboardData();
    }

    setupAdminTabs() {
        const tabButtons = document.querySelectorAll('.admin-tab-btn');
        tabButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                // Remove active from all tabs
                tabButtons.forEach(tab => {
                    tab.classList.remove('active', 'bg-green-600', 'text-white');
                    tab.classList.add('text-gray-600', 'hover:bg-gray-200');
                });
                
                // Add active to clicked tab
                btn.classList.add('active', 'bg-green-600', 'text-white');
                btn.classList.remove('text-gray-600', 'hover:bg-gray-200');
                
                // Load tab content
                const tabId = btn.id.replace('admin-tab-', '');
                this.loadAdminTabContent(tabId);
            });
        });
    }

    async loadAdminTabContent(tabId) {
        const contentArea = document.getElementById('admin-dashboard-content');
        if (!contentArea) return;
        
        // Show loading
        contentArea.innerHTML = `
            <div class="text-center py-8">
                <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
                <p class="text-gray-600">جاري تحميل البيانات...</p>
            </div>
        `;
        
        try {
            let data;
            switch (tabId) {
                case 'dashboard':
                    data = await this.fetchAdminData('/api/admin/dashboard');
                    this.displayAdminDashboard(data.dashboard);
                    break;
                case 'users':
                    data = await this.fetchAdminData('/api/admin/users');
                    this.displayAdminUsers(data.users);
                    break;
                case 'documents':
                    data = await this.fetchAdminData('/api/admin/documents');
                    this.displayAdminDocuments(data.documents);
                    break;
                case 'analytics':
                    data = await this.fetchAdminData('/api/admin/analytics');
                    this.displayAdminAnalytics(data.analytics);
                    break;
            }
        } catch (error) {
            console.error('Admin data error:', error);
            contentArea.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-exclamation-triangle text-red-500 text-4xl mb-4"></i>
                    <p class="text-red-600">خطأ في تحميل البيانات</p>
                </div>
            `;
        }
    }

    async fetchAdminData(endpoint) {
        const response = await fetch(endpoint);
        if (!response.ok) throw new Error('Failed to fetch admin data');
        return await response.json();
    }

    async loadAdminDashboardData() {
        await this.loadAdminTabContent('dashboard');
    }

    displayAdminDashboard(dashboard) {
        const contentArea = document.getElementById('admin-dashboard-content');
        if (!contentArea) return;
        
        contentArea.innerHTML = `
            <!-- System Health Cards -->
            <div class="grid md:grid-cols-4 gap-6 mb-8">
                <div class="stat-card rounded-lg p-6 text-center">
                    <div class="text-2xl font-bold text-green-600">${dashboard.totalProcessed || 0}</div>
                    <div class="text-sm text-gray-600">إجمالي المعالج</div>
                    <div class="text-xs text-green-600 mt-1">+${dashboard.todayProcessed || 0} اليوم</div>
                </div>
                
                <div class="stat-card rounded-lg p-6 text-center">
                    <div class="text-2xl font-bold text-blue-600">${dashboard.activeUsers || 0}</div>
                    <div class="text-sm text-gray-600">مستخدمين نشطين</div>
                    <div class="text-xs text-blue-600 mt-1">من أصل ${dashboard.totalUsers || 0}</div>
                </div>
                
                <div class="stat-card rounded-lg p-6 text-center">
                    <div class="text-2xl font-bold text-purple-600">${dashboard.serverUptime || 'N/A'}</div>
                    <div class="text-sm text-gray-600">وقت التشغيل</div>
                    <div class="text-xs text-green-600 mt-1">صحة النظام: ${dashboard.systemHealth || 'جيد'}</div>
                </div>
                
                <div class="stat-card rounded-lg p-6 text-center">
                    <div class="text-2xl font-bold text-orange-600">${dashboard.averageProcessingTime || 'N/A'}</div>
                    <div class="text-sm text-gray-600">متوسط المعالجة</div>
                    <div class="text-xs text-orange-600 mt-1">معدل الخطأ: ${dashboard.errorRate || '0%'}</div>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="grid lg:grid-cols-2 gap-8 mb-8">
                <div class="bg-white border rounded-lg p-6">
                    <h4 class="text-lg font-bold text-gray-800 mb-4">
                        <i class="fas fa-history ml-2"></i>
                        النشاط الأخير
                    </h4>
                    <div class="space-y-3 max-h-64 overflow-y-auto">
                        ${dashboard.recentActivity && dashboard.recentActivity.length > 0 ? 
                            dashboard.recentActivity.map(activity => `
                                <div class="flex justify-between items-center p-2 hover:bg-gray-50 rounded">
                                    <div>
                                        <span class="font-semibold text-gray-700">${activity.type}</span>
                                        <div class="text-xs text-gray-500">${new Date(activity.timestamp).toLocaleString('ar-SA')}</div>
                                    </div>
                                    <span class="text-xs px-2 py-1 rounded ${activity.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                                        ${activity.success ? 'نجح' : 'فشل'}
                                    </span>
                                </div>
                            `).join('') 
                            : '<p class="text-gray-500 text-center py-4">لا توجد أنشطة حديثة</p>'
                        }
                    </div>
                </div>
                
                <div class="bg-white border rounded-lg p-6">
                    <h4 class="text-lg font-bold text-gray-800 mb-4">
                        <i class="fas fa-chart-pie ml-2"></i>
                        أهم الفئات
                    </h4>
                    <div class="space-y-3">
                        ${dashboard.topCategories && Object.keys(dashboard.topCategories).length > 0 ?
                            Object.entries(dashboard.topCategories).map(([category, count]) => `
                                <div class="flex justify-between items-center">
                                    <span class="text-gray-700">${category}</span>
                                    <div class="flex items-center">
                                        <div class="bg-green-200 rounded-full h-2 w-16 ml-3">
                                            <div class="bg-green-600 h-2 rounded-full" style="width: ${(count / Math.max(...Object.values(dashboard.topCategories)) * 100)}%"></div>
                                        </div>
                                        <span class="font-semibold text-green-600">${count}</span>
                                    </div>
                                </div>
                            `).join('')
                            : '<p class="text-gray-500 text-center py-4">لا توجد بيانات فئات</p>'
                        }
                    </div>
                </div>
            </div>
            
            <!-- System Info -->
            <div class="bg-white border rounded-lg p-6">
                <h4 class="text-lg font-bold text-gray-800 mb-4">
                    <i class="fas fa-server ml-2"></i>
                    معلومات النظام
                </h4>
                <div class="grid md:grid-cols-3 gap-6">
                    <div class="bg-gray-50 rounded-lg p-4">
                        <h5 class="font-semibold text-gray-700 mb-2">الأداء</h5>
                        <div class="space-y-1 text-sm">
                            <div>متوسط المعالجة: <span class="font-semibold">${dashboard.averageProcessingTime || 'N/A'}</span></div>
                            <div>معدل النجاح: <span class="font-semibold text-green-600">99.1%</span></div>
                            <div>طابور المعالجة: <span class="font-semibold">${dashboard.processingQueue || 0}</span></div>
                        </div>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4">
                        <h5 class="font-semibold text-gray-700 mb-2">التخزين</h5>
                        <div class="space-y-1 text-sm">
                            <div>المستخدم: <span class="font-semibold">${dashboard.storageUsed || 'N/A'}</span></div>
                            <div>المتاح: <span class="font-semibold text-green-600">200GB</span></div>
                            <div>النسخ الاحتياطية: <span class="font-semibold">يومية</span></div>
                        </div>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4">
                        <h5 class="font-semibold text-gray-700 mb-2">الأمان</h5>
                        <div class="space-y-1 text-sm">
                            <div>SSL: <span class="font-semibold text-green-600">مفعل</span></div>
                            <div>المصادقة: <span class="font-semibold text-green-600">JWT</span></div>
                            <div>آخر فحص: <span class="font-semibold">منذ ساعة</span></div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    displayAdminUsers(users) {
        const contentArea = document.getElementById('admin-dashboard-content');
        if (!contentArea) return;
        
        contentArea.innerHTML = `
            <div class="bg-white border rounded-lg p-6">
                <div class="flex justify-between items-center mb-6">
                    <h4 class="text-lg font-bold text-gray-800">
                        <i class="fas fa-users ml-2"></i>
                        إدارة المستخدمين (${users ? users.length : 0})
                    </h4>
                    <div class="flex gap-2">
                        <input type="search" placeholder="البحث عن مستخدم..." class="px-3 py-2 border rounded">
                        <button class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full table-auto">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="text-right p-3 font-semibold">الاسم</th>
                                <th class="text-right p-3 font-semibold">البريد الإلكتروني</th>
                                <th class="text-right p-3 font-semibold">تاريخ التسجيل</th>
                                <th class="text-right p-3 font-semibold">آخر نشاط</th>
                                <th class="text-right p-3 font-semibold">الحالة</th>
                                <th class="text-center p-3 font-semibold">إجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${users && users.length > 0 ? users.map(user => `
                                <tr class="border-t hover:bg-gray-50">
                                    <td class="p-3">
                                        <div class="flex items-center">
                                            <div class="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center ml-2">
                                                <span class="text-green-600 text-sm font-bold">${user.name ? user.name.charAt(0) : 'م'}</span>
                                            </div>
                                            ${user.name || 'مجهول'}
                                        </div>
                                    </td>
                                    <td class="p-3 text-sm">${user.email}</td>
                                    <td class="p-3 text-sm">${user.registerTime ? new Date(user.registerTime).toLocaleDateString('ar-SA') : 'غير محدد'}</td>
                                    <td class="p-3 text-sm">${user.lastActive ? new Date(user.lastActive).toLocaleString('ar-SA') : 'غير محدد'}</td>
                                    <td class="p-3">
                                        <span class="text-xs px-2 py-1 rounded bg-green-100 text-green-800">نشط</span>
                                    </td>
                                    <td class="p-3 text-center">
                                        <div class="flex justify-center gap-2">
                                            <button class="text-blue-600 hover:text-blue-800 text-sm">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="text-gray-600 hover:text-gray-800 text-sm">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `).join('') : `
                                <tr>
                                    <td colspan="6" class="text-center py-8 text-gray-500">
                                        <i class="fas fa-users text-4xl mb-4"></i>
                                        <p>لا توجد مستخدمين مسجلين</p>
                                    </td>
                                </tr>
                            `}
                        </tbody>
                    </table>
                </div>
                
                ${users && users.length > 10 ? `
                <div class="mt-6 flex justify-center">
                    <div class="flex gap-2">
                        <button class="px-3 py-1 border rounded hover:bg-gray-50">السابق</button>
                        <button class="px-3 py-1 bg-green-600 text-white rounded">1</button>
                        <button class="px-3 py-1 border rounded hover:bg-gray-50">2</button>
                        <button class="px-3 py-1 border rounded hover:bg-gray-50">التالي</button>
                    </div>
                </div>
                ` : ''}
            </div>
        `;
    }

    displayAdminDocuments(documents) {
        const contentArea = document.getElementById('admin-dashboard-content');
        if (!contentArea) return;
        
        contentArea.innerHTML = `
            <div class="bg-white border rounded-lg p-6">
                <div class="flex justify-between items-center mb-6">
                    <h4 class="text-lg font-bold text-gray-800">
                        <i class="fas fa-file-alt ml-2"></i>
                        سجل الوثائق المعالجة (${documents ? documents.length : 0})
                    </h4>
                    <div class="flex gap-2">
                        <select class="px-3 py-2 border rounded">
                            <option>جميع الأنواع</option>
                            <option>ترميم</option>
                            <option>استخراج نص</option>
                            <option>تصنيف</option>
                        </select>
                        <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
                            <i class="fas fa-download ml-1"></i>
                            تصدير
                        </button>
                    </div>
                </div>
                
                <div class="grid md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                        <div class="text-xl font-bold text-green-600">${documents ? documents.filter(d => d.type === 'restoration').length : 0}</div>
                        <div class="text-sm text-green-700">ترميم</div>
                    </div>
                    <div class="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
                        <div class="text-xl font-bold text-red-600">${documents ? documents.filter(d => d.type === 'ocr').length : 0}</div>
                        <div class="text-sm text-red-700">استخراج نص</div>
                    </div>
                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
                        <div class="text-xl font-bold text-blue-600">${documents ? documents.filter(d => d.type === 'classification').length : 0}</div>
                        <div class="text-sm text-blue-700">تصنيف</div>
                    </div>
                    <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center">
                        <div class="text-xl font-bold text-gray-600">${documents ? documents.filter(d => d.success).length : 0}</div>
                        <div class="text-sm text-gray-700">نجح</div>
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full table-auto">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="text-right p-3 font-semibold">المعرف</th>
                                <th class="text-right p-3 font-semibold">النوع</th>
                                <th class="text-right p-3 font-semibold">التاريخ</th>
                                <th class="text-right p-3 font-semibold">الحالة</th>
                                <th class="text-right p-3 font-semibold">التفاصيل</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${documents && documents.length > 0 ? documents.slice(0, 20).map(doc => `
                                <tr class="border-t hover:bg-gray-50">
                                    <td class="p-3 text-sm font-mono">${doc.id}</td>
                                    <td class="p-3">
                                        <span class="text-xs px-2 py-1 rounded ${
                                            doc.type === 'restoration' ? 'bg-green-100 text-green-800' :
                                            doc.type === 'ocr' ? 'bg-red-100 text-red-800' :
                                            'bg-blue-100 text-blue-800'
                                        }">
                                            ${doc.type === 'restoration' ? 'ترميم' : 
                                              doc.type === 'ocr' ? 'استخراج نص' : 'تصنيف'}
                                        </span>
                                    </td>
                                    <td class="p-3 text-sm">${new Date(doc.timestamp).toLocaleString('ar-SA')}</td>
                                    <td class="p-3">
                                        <span class="text-xs px-2 py-1 rounded ${doc.success ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}">
                                            ${doc.success ? 'نجح' : 'فشل'}
                                        </span>
                                    </td>
                                    <td class="p-3 text-sm">
                                        ${doc.mode ? `النمط: ${doc.mode}` : ''}
                                        ${doc.category ? `الفئة: ${doc.category}` : ''}
                                        ${doc.language ? `اللغة: ${doc.language}` : ''}
                                    </td>
                                </tr>
                            `).join('') : `
                                <tr>
                                    <td colspan="5" class="text-center py-8 text-gray-500">
                                        <i class="fas fa-file-alt text-4xl mb-4"></i>
                                        <p>لا توجد وثائق معالجة</p>
                                    </td>
                                </tr>
                            `}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    displayAdminAnalytics(analytics) {
        const contentArea = document.getElementById('admin-dashboard-content');
        if (!contentArea) return;
        
        contentArea.innerHTML = `
            <div class="space-y-8">
                <!-- Performance Metrics -->
                <div class="bg-white border rounded-lg p-6">
                    <h4 class="text-lg font-bold text-gray-800 mb-6">
                        <i class="fas fa-tachometer-alt ml-2"></i>
                        مقاييس الأداء
                    </h4>
                    <div class="grid md:grid-cols-4 gap-6">
                        ${analytics && analytics.performanceMetrics ? Object.entries(analytics.performanceMetrics).map(([key, value]) => `
                            <div class="text-center p-4 bg-gray-50 rounded-lg">
                                <div class="text-xl font-bold text-blue-600">${value}</div>
                                <div class="text-sm text-gray-600">${this.getMetricLabel(key)}</div>
                            </div>
                        `).join('') : '<p class="text-gray-500">لا توجد بيانات أداء</p>'}
                    </div>
                </div>
                
                <!-- Daily Processing Chart -->
                <div class="bg-white border rounded-lg p-6">
                    <h4 class="text-lg font-bold text-gray-800 mb-6">
                        <i class="fas fa-chart-line ml-2"></i>
                        المعالجة اليومية
                    </h4>
                    <div class="h-64 flex items-center justify-center bg-gray-50 rounded">
                        <canvas id="daily-chart" width="600" height="200"></canvas>
                    </div>
                </div>
                
                <!-- User Activity -->
                <div class="grid lg:grid-cols-2 gap-8">
                    <div class="bg-white border rounded-lg p-6">
                        <h4 class="text-lg font-bold text-gray-800 mb-4">
                            <i class="fas fa-users ml-2"></i>
                            نشاط المستخدمين
                        </h4>
                        ${analytics && analytics.userActivity ? `
                            <div class="space-y-4">
                                <div class="flex justify-between items-center">
                                    <span>تسجيلات جديدة</span>
                                    <span class="font-bold text-green-600">${analytics.userActivity.newRegistrations}</span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span>نشط اليوم</span>
                                    <span class="font-bold text-blue-600">${analytics.userActivity.activeToday}</span>
                                </div>
                                <div class="mt-4">
                                    <h5 class="font-semibold mb-2">أكثر المستخدمين نشاطاً</h5>
                                    <div class="space-y-2">
                                        ${analytics.userActivity.topUsers ? analytics.userActivity.topUsers.map(user => `
                                            <div class="flex justify-between text-sm">
                                                <span>${user.name}</span>
                                                <span class="text-gray-600">${user.documents} وثيقة</span>
                                            </div>
                                        `).join('') : ''}
                                    </div>
                                </div>
                            </div>
                        ` : '<p class="text-gray-500">لا توجد بيانات نشاط</p>'}
                    </div>
                    
                    <div class="bg-white border rounded-lg p-6">
                        <h4 class="text-lg font-bold text-gray-800 mb-4">
                            <i class="fas fa-chart-pie ml-2"></i>
                            توزيع الفئات
                        </h4>
                        ${analytics && analytics.categoryTrends ? `
                            <div class="space-y-3">
                                ${Object.entries(analytics.categoryTrends).map(([category, count]) => `
                                    <div class="flex justify-between items-center">
                                        <span class="text-gray-700">${category}</span>
                                        <div class="flex items-center">
                                            <div class="bg-green-200 rounded-full h-2 w-20 ml-3">
                                                <div class="bg-green-600 h-2 rounded-full" style="width: ${(count / Math.max(...Object.values(analytics.categoryTrends)) * 100)}%"></div>
                                            </div>
                                            <span class="font-semibold text-green-600">${count}</span>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        ` : '<p class="text-gray-500">لا توجد بيانات فئات</p>'}
                    </div>
                </div>
                
                <!-- Predictions -->
                ${analytics && analytics.predictions ? `
                <div class="bg-white border rounded-lg p-6">
                    <h4 class="text-lg font-bold text-gray-800 mb-4">
                        <i class="fas fa-crystal-ball ml-2"></i>
                        التوقعات والتوصيات
                    </h4>
                    <div class="grid md:grid-cols-3 gap-6">
                        <div class="bg-blue-50 rounded-lg p-4">
                            <h5 class="font-semibold text-blue-800 mb-2">النمو المتوقع</h5>
                            <p class="text-2xl font-bold text-blue-600">${analytics.predictions.expectedGrowth}</p>
                        </div>
                        <div class="bg-green-50 rounded-lg p-4">
                            <h5 class="font-semibold text-green-800 mb-2">ساعات الذروة</h5>
                            <p class="text-lg font-semibold text-green-600">${analytics.predictions.peakHours}</p>
                        </div>
                        <div class="bg-yellow-50 rounded-lg p-4">
                            <h5 class="font-semibold text-yellow-800 mb-2">التوصيات</h5>
                            <ul class="text-sm text-yellow-700">
                                ${analytics.predictions.recommendedUpgrades.map(upgrade => `<li>• ${upgrade}</li>`).join('')}
                            </ul>
                        </div>
                    </div>
                </div>
                ` : ''}
            </div>
        `;
        
        // Initialize chart if Chart.js is available
        if (typeof Chart !== 'undefined' && analytics && analytics.dailyProcessing) {
            this.initDailyChart(analytics.dailyProcessing);
        }
    }

    getMetricLabel(key) {
        const labels = {
            'averageProcessingTime': 'متوسط المعالجة',
            'successRate': 'معدل النجاح',
            'errorRate': 'معدل الخطأ',
            'systemLoad': 'حمولة النظام'
        };
        return labels[key] || key;
    }

    initDailyChart(dailyData) {
        setTimeout(() => {
            const ctx = document.getElementById('daily-chart');
            if (!ctx) return;
            
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: dailyData.map(d => d.day),
                    datasets: [{
                        label: 'الوثائق',
                        data: dailyData.map(d => d.documents),
                        borderColor: '#00A550',
                        backgroundColor: 'rgba(0, 165, 80, 0.1)',
                        tension: 0.4
                    }, {
                        label: 'المستخدمين',
                        data: dailyData.map(d => d.users),
                        borderColor: '#E4312B',
                        backgroundColor: 'rgba(228, 49, 43, 0.1)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            rtl: true,
                            textDirection: 'rtl'
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }, 100);
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 بايت';
        const k = 1024;
        const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    setupPWASupport() {
        // Check if PWA is supported
        if ('serviceWorker' in navigator) {
            // Register service worker
            navigator.serviceWorker.register('/static/sw.js')
                .then((registration) => {
                    console.log('ServiceWorker registered successfully:', registration.scope);
                })
                .catch((error) => {
                    console.log('ServiceWorker registration failed:', error);
                });
        }

        // Handle PWA install prompt
        let deferredPrompt;
        
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            deferredPrompt = e;
            this.showPWAInstallPrompt();
        });

        document.getElementById('pwa-install-btn')?.addEventListener('click', () => {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                deferredPrompt.userChoice.then((choiceResult) => {
                    if (choiceResult.outcome === 'accepted') {
                        this.showNotification('تم تثبيت التطبيق بنجاح', 'success');
                    }
                    deferredPrompt = null;
                    this.hidePWAInstallPrompt();
                });
            }
        });

        document.getElementById('pwa-dismiss-btn')?.addEventListener('click', () => {
            this.hidePWAInstallPrompt();
        });
    }

    showPWAInstallPrompt() {
        const prompt = document.getElementById('pwa-install-prompt');
        if (prompt) {
            prompt.classList.remove('hidden');
        }
    }

    hidePWAInstallPrompt() {
        const prompt = document.getElementById('pwa-install-prompt');
        if (prompt) {
            prompt.classList.add('hidden');
        }
    }

    showNotification(message, type = 'info') {
        const colors = {
            success: 'bg-green-600',
            error: 'bg-red-600',
            info: 'bg-blue-600',
            warning: 'bg-yellow-600'
        };

        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            info: 'fas fa-info-circle',
            warning: 'fas fa-exclamation-triangle'
        };

        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 ${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 max-w-sm`;
        notification.innerHTML = `
            <div class="flex items-center">
                <i class="${icons[type]} ml-2"></i>
                <span class="text-sm">${message}</span>
            </div>
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.opacity = '0';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
}

// Global functions for onclick handlers
window.showAuthModal = function() {
    window.documentManager?.showAuthModal();
};

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.documentManager = new EnhancedDocumentManager();
    });
} else {
    window.documentManager = new EnhancedDocumentManager();
}