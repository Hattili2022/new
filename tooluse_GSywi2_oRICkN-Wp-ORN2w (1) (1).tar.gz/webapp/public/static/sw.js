// Service Worker for Palestinian National Library PWA
const CACHE_NAME = 'palestinian-library-v1';
const urlsToCache = [
  '/',
  '/static/app.js',
  '/static/manifest.json',
  '/static/icon.svg',
  'https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;900&display=swap',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://cdn.tailwindcss.com'
];

// Install event
self.addEventListener('install', (event) => {
  console.log('Service Worker installing...');
  
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Opened cache');
        return cache.addAll(urlsToCache);
      })
      .catch((error) => {
        console.log('Cache addAll failed:', error);
      })
  );
});

// Fetch event
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // Return cached version or fetch from network
        if (response) {
          return response;
        }
        
        return fetch(event.request)
          .then((response) => {
            // Check if we received a valid response
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // Clone the response
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          });
      })
  );
});

// Activate event
self.addEventListener('activate', (event) => {
  console.log('Service Worker activating...');
  
  const cacheWhitelist = [CACHE_NAME];
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Background sync for offline document processing
self.addEventListener('sync', (event) => {
  console.log('Background sync triggered');
  
  if (event.tag === 'document-upload') {
    event.waitUntil(syncDocuments());
  }
});

async function syncDocuments() {
  try {
    // Handle offline document uploads when connection is restored
    const pendingUploads = await getPendingUploads();
    
    for (const upload of pendingUploads) {
      try {
        await processDocument(upload);
        await removePendingUpload(upload.id);
      } catch (error) {
        console.log('Failed to sync document:', error);
      }
    }
  } catch (error) {
    console.log('Sync failed:', error);
  }
}

async function getPendingUploads() {
  // Implementation to get pending uploads from IndexedDB
  return [];
}

async function processDocument(upload) {
  // Implementation to process uploaded document
  return fetch('/api/restore', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(upload)
  });
}

async function removePendingUpload(id) {
  // Implementation to remove processed upload from IndexedDB
  console.log('Removing pending upload:', id);
}

// Push notifications
self.addEventListener('push', (event) => {
  console.log('Push message received');
  
  const options = {
    body: event.data ? event.data.text() : 'تم معالجة وثيقتك بنجاح',
    icon: '/static/icon-192x192.png',
    badge: '/static/icon-72x72.png',
    vibrate: [200, 100, 200],
    dir: 'rtl',
    lang: 'ar',
    actions: [
      {
        action: 'view',
        title: 'عرض النتيجة',
        icon: '/static/icon-72x72.png'
      },
      {
        action: 'close',
        title: 'إغلاق',
        icon: '/static/icon-72x72.png'
      }
    ]
  };
  
  event.waitUntil(
    self.registration.showNotification('المكتبة الوطنية الفلسطينية', options)
  );
});

// Notification click handler
self.addEventListener('notificationclick', (event) => {
  console.log('Notification click received');
  
  event.notification.close();
  
  if (event.action === 'view') {
    event.waitUntil(
      clients.openWindow('/')
    );
  }
});