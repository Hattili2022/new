import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'
import { jwt, sign, verify } from 'hono/jwt'
import { setCookie, getCookie } from 'hono/cookie'

// Type definitions for Cloudflare bindings
type Bindings = {
  DB: D1Database;
}

const app = new Hono<{ Bindings: Bindings }>()

// Enable CORS for API endpoints
app.use('/api/*', cors())
app.use('/admin/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// Authentication configuration
const JWT_SECRET = 'palestine-digital-library-secret-2024'
const ADMIN_USERNAME = 'admin'
const ADMIN_PASSWORD = 'palestine123'

// Admin authentication middleware
const adminAuth = async (c: any, next: any) => {
  const token = getCookie(c, 'admin-token')
  
  if (!token) {
    return c.redirect('/admin/login')
  }
  
  try {
    const payload = await verify(token, JWT_SECRET)
    c.set('admin', payload)
    await next()
  } catch (error) {
    return c.redirect('/admin/login')
  }
}

// =============================================================================
// MAIN WEBSITE ROUTES
// =============================================================================

// Main website homepage
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>المكتبة الرقمية الفلسطينية الوطنية</title>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="/static/professional-style.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Cairo:wght@300;400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="/static/favicon.ico">
    </head>
    <body>
        <!-- Modern Professional Header -->
        <header class="modern-header" id="mainHeader">
            <div class="header-container">
                <a href="/" class="brand-logo">
                    <div class="brand-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <span>المكتبة الرقمية الفلسطينية</span>
                </a>
                
                <nav>
                    <ul class="nav-links">
                        <li><a href="#books" onclick="app.scrollToSection('books-section')" class="nav-link">
                            <i class="fas fa-book"></i>
                            الكتب
                        </a></li>
                        <li><a href="#audio" onclick="app.scrollToSection('audio-section')" class="nav-link">
                            <i class="fas fa-headphones"></i>
                            الصوتيات
                        </a></li>
                        <li><a href="#video" onclick="app.scrollToSection('video-section')" class="nav-link">
                            <i class="fas fa-video"></i>
                            الفيديو
                        </a></li>
                        <li><a href="#maps" onclick="app.scrollToSection('maps-section')" class="nav-link">
                            <i class="fas fa-map"></i>
                            الخرائط
                        </a></li>
                        <li><a href="#vr" onclick="app.scrollToSection('vr-section')" class="nav-link">
                            <i class="fas fa-vr-cardboard"></i>
                            VR
                        </a></li>
                        <li><a href="#archive" onclick="app.showArchive()" class="nav-link">
                            <i class="fas fa-archive"></i>
                            الأرشيف
                        </a></li>
                    </ul>
                </nav>
                
                <div class="nav-actions">
                    <a href="/admin" class="btn-secondary">
                        <i class="fas fa-cog"></i>
                        لوحة التحكم
                    </a>
                    <button class="btn-primary" onclick="app.toggleDownloadMenu()">
                        <i class="fas fa-download"></i>
                        التطبيقات
                    </button>
                    <div class="download-menu" id="downloadMenu" style="position: absolute; top: 100%; left: 0; background: white; border-radius: 12px; box-shadow: 0 20px 40px rgba(0,0,0,0.15); padding: 12px; min-width: 220px; display: none; z-index: 1000; backdrop-filter: blur(20px);">
                        <a href="/download/mobile" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: #374151; text-decoration: none; border-radius: 8px; transition: all 0.2s; font-weight: 500;">
                            <i class="fas fa-mobile-alt" style="color: #ce1126;"></i>
                            تطبيق الموبايل
                        </a>
                        <a href="/download/desktop" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: #374151; text-decoration: none; border-radius: 8px; transition: all 0.2s; font-weight: 500;">
                            <i class="fas fa-desktop" style="color: #ce1126;"></i>
                            تطبيق سطح المكتب
                        </a>
                        <a href="/download/source" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: #374151; text-decoration: none; border-radius: 8px; transition: all 0.2s; font-weight: 500;">
                            <i class="fas fa-code" style="color: #ce1126;"></i>
                            شيفرة المصدر
                        </a>
                        <a href="/download/complete" style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; color: #374151; text-decoration: none; border-radius: 8px; transition: all 0.2s; font-weight: 500;">
                            <i class="fas fa-archive" style="color: #ce1126;"></i>
                            الحزمة الكاملة
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Hero Section -->
        <section class="hero-section">
            <div class="hero-container">
                <div class="hero-content">
                    <h1 class="animate-fade-up">المكتبة الرقمية الفلسطينية الوطنية</h1>
                    <p class="animate-fade-up" style="animation-delay: 0.2s;">منصة رقمية شاملة تهدف إلى حفظ وتوثيق التراث الفلسطيني والثقافة العربية، وجعلها متاحة للأجيال القادمة في جميع أنحاء العالم</p>
                    <div class="hero-actions animate-fade-up" style="animation-delay: 0.4s;">
                        <a href="#books" onclick="app.scrollToSection('books-section')" class="btn-primary">
                            <i class="fas fa-search"></i>
                            استكشف المكتبة
                        </a>
                        <a href="/admin" class="btn-secondary">
                            <i class="fas fa-plus"></i>
                            أضف محتوى
                        </a>
                    </div>
                </div>
                <div class="hero-visual animate-fade-right" style="animation-delay: 0.6s;">
                    <img src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=600&h=400&fit=crop&q=80" alt="المكتبة الفلسطينية" class="hero-image">
                </div>
            </div>
        </section>

        <!-- Statistics Section -->
        <section class="stats-section">
            <div class="stats-container">
                <div class="stats-grid">
                    <div class="stat-card animate-fade-up" style="animation-delay: 0.1s;">
                        <div class="stat-icon">
                            <i class="fas fa-book"></i>
                        </div>
                        <span class="stat-number" id="totalBooks">3</span>
                        <div class="stat-label">كتاب ومرجع</div>
                    </div>
                    
                    <div class="stat-card animate-fade-up" style="animation-delay: 0.2s;">
                        <div class="stat-icon">
                            <i class="fas fa-headphones"></i>
                        </div>
                        <span class="stat-number" id="totalAudio">3</span>
                        <div class="stat-label">تسجيل صوتي</div>
                    </div>
                    
                    <div class="stat-card animate-fade-up" style="animation-delay: 0.3s;">
                        <div class="stat-icon">
                            <i class="fas fa-video"></i>
                        </div>
                        <span class="stat-number" id="totalVideos">3</span>
                        <div class="stat-label">فيديو ووثائقي</div>
                    </div>
                    
                    <div class="stat-card animate-fade-up" style="animation-delay: 0.4s;">
                        <div class="stat-icon">
                            <i class="fas fa-map"></i>
                        </div>
                        <span class="stat-number" id="totalMaps">3</span>
                        <div class="stat-label">خريطة تاريخية</div>
                    </div>
                </div>
            </div>
        </section>

            <!-- Books Section -->
            <section class="content-section" id="books-section">
                <div class="section-header">
                    <h2 class="section-title">الكتب والمراجع</h2>
                    <p class="section-subtitle">مجموعة متنوعة من الكتب والمراجع في التاريخ والأدب والثقافة الفلسطينية</p>
                </div>
                <div class="content-grid" id="booksGrid">
                    <!-- Books will be loaded here -->
                </div>
            </section>

            <!-- Audio Section -->
            <section class="content-section" id="audio-section">
                <div class="section-container">
                    <div class="section-header">
                        <h2 class="section-title animate-fade-up">
                            <i class="fas fa-headphones"></i>
                            المحتوى الصوتي
                        </h2>
                        <p class="section-subtitle animate-fade-up" style="animation-delay: 0.1s;">تسجيلات صوتية ومقاطع نادرة من التراث الفلسطيني</p>
                        <div class="section-filters animate-fade-up" style="animation-delay: 0.2s;">
                            <select id="audioCategory" onchange="app.filterContent('audio')" class="filter-select">
                                <option value="">جميع الفئات</option>
                                <option value="speeches">الخطب</option>
                                <option value="poetry">الشعر</option>
                                <option value="interviews">المقابلات</option>
                                <option value="folk_music">التراث الموسيقي</option>
                            </select>
                            <button onclick="app.toggleAudioView()" class="view-toggle-btn">
                                <i class="fas fa-th-large"></i>
                                عرض شبكي
                            </button>
                        </div>
                    </div>
                    <div class="content-grid animate-fade-up" id="audioGrid" style="animation-delay: 0.3s;">
                        <!-- Audio content will be loaded here -->
                    </div>
                </div>
            </section>

            <!-- Video Section -->
            <section class="content-section" id="video-section">
                <div class="section-container">
                    <div class="section-header">
                        <h2 class="section-title animate-fade-up">
                            <i class="fas fa-video"></i>
                            المحتوى المرئي
                        </h2>
                        <p class="section-subtitle animate-fade-up" style="animation-delay: 0.1s;">أفلام وثائقيات وبرامج ثقافية فلسطينية</p>
                        <div class="section-filters animate-fade-up" style="animation-delay: 0.2s;">
                            <select id="videoCategory" onchange="app.filterContent('video')" class="filter-select">
                                <option value="">جميع الفئات</option>
                                <option value="documentaries">الوثائقيات</option>
                                <option value="cultural">البرامج الثقافية</option>
                                <option value="historical">التاريخية</option>
                                <option value="educational">التعليمية</option>
                            </select>
                            <button onclick="app.toggleVideoView()" class="view-toggle-btn">
                                <i class="fas fa-th-large"></i>
                                عرض شبكي
                            </button>
                        </div>
                    </div>
                    <div class="content-grid animate-fade-up" id="videoGrid" style="animation-delay: 0.3s;">
                        <!-- Video content will be loaded here -->
                    </div>
                </div>
            </section>

            <!-- Maps Section -->
            <section class="content-section" id="maps-section">
                <div class="section-container">
                    <div class="section-header">
                        <h2 class="section-title animate-fade-up">
                            <i class="fas fa-map"></i>
                            الخرائط التاريخية
                        </h2>
                        <p class="section-subtitle animate-fade-up" style="animation-delay: 0.1s;">خرائط تاريخية ومعاصرة لفلسطين والمنطقة</p>
                        <div class="section-filters animate-fade-up" style="animation-delay: 0.2s;">
                            <select id="mapsCategory" onchange="app.filterContent('maps')" class="filter-select">
                                <option value="">جميع الفترات</option>
                                <option value="ancient">القديمة</option>
                                <option value="ottoman">العثمانية</option>
                                <option value="mandate">الانتداب</option>
                                <option value="modern">المعاصرة</option>
                            </select>
                            <button onclick="app.toggleMapView()" class="view-toggle-btn">
                                <i class="fas fa-globe"></i>
                                عرض تفاعلي
                            </button>
                        </div>
                    </div>
                    <div class="content-grid animate-fade-up" id="mapsGrid" style="animation-delay: 0.3s;">
                        <!-- Maps will be loaded here -->
                    </div>
                </div>
            </section>

            <!-- VR Heritage Section -->
            <section class="content-section" id="vr-section">
                <div class="section-container">
                    <div class="section-header">
                        <h2 class="section-title animate-fade-up">
                            <i class="fas fa-vr-cardboard"></i>
                            التراث الافتراضي
                        </h2>
                        <p class="section-subtitle animate-fade-up" style="animation-delay: 0.1s;">جولات افتراضية في المواقع التاريخية والأثرية الفلسطينية</p>
                        <div class="section-filters animate-fade-up" style="animation-delay: 0.2s;">
                            <select id="vrCategory" onchange="app.filterContent('vr')" class="filter-select">
                                <option value="">جميع الفئات</option>
                                <option value="archaeological">الأثرية</option>
                                <option value="religious">الدينية</option>
                                <option value="historical">التاريخية</option>
                                <option value="cultural">الثقافية</option>
                            </select>
                            <button onclick="app.toggleVRMode()" class="vr-mode-btn">
                                <i class="fas fa-vr-cardboard"></i>
                                الوضع الافتراضي
                            </button>
                        </div>
                    </div>
                    <div class="content-grid animate-fade-up" id="vrGrid" style="animation-delay: 0.3s;">
                        <!-- VR content will be loaded here -->
                    </div>
                </div>
            </section>

            <!-- Archive Section -->
            <section class="content-section archive-section" id="archive-section" style="display: none;">
                <div class="section-container">
                    <div class="section-header">
                        <h2 class="section-title animate-fade-up">
                            <i class="fas fa-archive"></i>
                            أرشيف المجموعات التراثية
                        </h2>
                        <p class="section-subtitle animate-fade-up" style="animation-delay: 0.1s;">
                            اكتشف مجموعاتنا النادرة من الوثائق والمواد التاريخية المحفوظة رقمياً
                        </p>
                        <div class="archive-controls animate-fade-up" style="animation-delay: 0.2s;">
                            <select id="archiveCategory" onchange="app.filterArchive()" class="filter-select">
                                <option value="">جميع المجموعات</option>
                                <option value="documents">الوثائق</option>
                                <option value="newspapers">الصحف</option>
                                <option value="photos">الصور</option>
                                <option value="manuscripts">المخطوطات</option>
                            </select>
                            <button onclick="app.showArchiveTimeline()" class="timeline-btn">
                                <i class="fas fa-clock"></i>
                                الخط الزمني
                            </button>
                        </div>
                    </div>
                    
                    <!-- Archive Statistics -->
                    <div class="archive-stats animate-fade-up" style="animation-delay: 0.3s;">
                        <div class="archive-stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-layer-group"></i>
                            </div>
                            <div class="stat-info">
                                <div class="stat-number" id="totalCollections">6</div>
                                <div class="stat-label">مجموعة أرشيفية</div>
                            </div>
                        </div>
                        <div class="archive-stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-file-alt"></i>
                            </div>
                            <div class="stat-info">
                                <div class="stat-number" id="totalItems">5,159</div>
                                <div class="stat-label">عنصر محفوظ</div>
                            </div>
                        </div>
                        <div class="archive-stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-download"></i>
                            </div>
                            <div class="stat-info">
                                <div class="stat-number">15,240</div>
                                <div class="stat-label">تحميل مكتمل</div>
                            </div>
                        </div>
                        <div class="archive-stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-calendar-plus"></i>
                            </div>
                            <div class="stat-info">
                                <div class="stat-number">45</div>
                                <div class="stat-label">إضافة أسبوعية</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Archive Grid -->
                    <div class="archive-grid animate-fade-up" id="archiveGrid" style="animation-delay: 0.4s;">
                        <!-- Archive collections will be loaded here -->
                    </div>
                </div>
            </section>
        </main>

        <!-- Professional Footer -->
        <footer class="professional-footer">
            <div class="footer-container">
                <!-- Footer Main Content -->
                <div class="footer-content">
                    <!-- Brand Section -->
                    <div class="footer-brand">
                        <div class="footer-logo">
                            <div class="brand-icon">
                                <i class="fas fa-book-open"></i>
                            </div>
                            <h3>المكتبة الرقمية الفلسطينية الوطنية</h3>
                        </div>
                        <p class="footer-description">
                            منصة رقمية شاملة تهدف إلى حفظ وتوثيق التراث الفلسطيني والثقافة العربية، وجعلها متاحة للأجيال القادمة في جميع أنحاء العالم
                        </p>
                        <div class="social-links">
                            <a href="#" class="social-link" title="فيسبوك">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="#" class="social-link" title="تويتر">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="#" class="social-link" title="يوتيوب">
                                <i class="fab fa-youtube"></i>
                            </a>
                            <a href="#" class="social-link" title="لينكد إن">
                                <i class="fab fa-linkedin-in"></i>
                            </a>
                        </div>
                    </div>
                    
                    <!-- Quick Links -->
                    <div class="footer-section">
                        <h4 class="footer-title">التصفح السريع</h4>
                        <ul class="footer-links">
                            <li><a href="#" onclick="app.scrollToSection('books-section')">
                                <i class="fas fa-book"></i>
                                الكتب والمراجع
                            </a></li>
                            <li><a href="#" onclick="app.scrollToSection('audio-section')">
                                <i class="fas fa-headphones"></i>
                                المحتوى الصوتي
                            </a></li>
                            <li><a href="#" onclick="app.scrollToSection('video-section')">
                                <i class="fas fa-video"></i>
                                المحتوى المرئي
                            </a></li>
                            <li><a href="#" onclick="app.scrollToSection('maps-section')">
                                <i class="fas fa-map"></i>
                                الخرائط التاريخية
                            </a></li>
                            <li><a href="#" onclick="app.showArchive()">
                                <i class="fas fa-archive"></i>
                                الأرشيف
                            </a></li>
                        </ul>
                    </div>
                    
                    <!-- Downloads -->
                    <div class="footer-section">
                        <h4 class="footer-title">التحميلات</h4>
                        <ul class="footer-links">
                            <li><a href="/download/mobile">
                                <i class="fas fa-mobile-alt"></i>
                                تطبيق الموبايل
                            </a></li>
                            <li><a href="/download/desktop">
                                <i class="fas fa-desktop"></i>
                                تطبيق سطح المكتب
                            </a></li>
                            <li><a href="/download/source">
                                <i class="fas fa-code"></i>
                                شيفرة المصدر
                            </a></li>
                            <li><a href="/download/complete">
                                <i class="fas fa-archive"></i>
                                الحزمة الكاملة
                            </a></li>
                        </ul>
                    </div>
                    
                    <!-- Admin & Resources -->
                    <div class="footer-section">
                        <h4 class="footer-title">الموارد والدعم</h4>
                        <ul class="footer-links">
                            <li><a href="/admin">
                                <i class="fas fa-cog"></i>
                                لوحة التحكم
                            </a></li>
                            <li><a href="/docs">
                                <i class="fas fa-file-alt"></i>
                                الوثائق التقنية
                            </a></li>
                            <li><a href="/docs/deployment/user-manual">
                                <i class="fas fa-question-circle"></i>
                                دليل المستخدم
                            </a></li>
                            <li><a href="#" onclick="app.showContactModal()">
                                <i class="fas fa-envelope"></i>
                                تواصل معنا
                            </a></li>
                        </ul>
                    </div>
                </div>
                
                <!-- Footer Statistics -->
                <div class="footer-stats">
                    <div class="footer-stat">
                        <div class="stat-number" id="footerBooksCount">3</div>
                        <div class="stat-label">كتاب ومرجع</div>
                    </div>
                    <div class="footer-stat">
                        <div class="stat-number" id="footerAudioCount">3</div>
                        <div class="stat-label">تسجيل صوتي</div>
                    </div>
                    <div class="footer-stat">
                        <div class="stat-number" id="footerVideoCount">3</div>
                        <div class="stat-label">محتوى مرئي</div>
                    </div>
                    <div class="footer-stat">
                        <div class="stat-number">15,240</div>
                        <div class="stat-label">تحميل</div>
                    </div>
                </div>
                
                <!-- Footer Bottom -->
                <div class="footer-bottom">
                    <div class="footer-copyright">
                        <p>&copy; 2024 المكتبة الرقمية الفلسطينية الوطنية - جميع الحقوق محفوظة</p>
                    </div>
                    <div class="footer-meta">
                        <span>نسخة 2.1.0</span>
                        <span>|</span>
                        <span>آخر تحديث: يناير 2024</span>
                        <span>|</span>
                        <a href="#" onclick="app.showPrivacyPolicy()">سياسة الخصوصية</a>
                    </div>
                </div>
            </div>
        </footer>

        <!-- Audio Player Modal -->
        <div id="audioModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 id="audioTitle"></h3>
                    <button class="modal-close" onclick="app.closeAudioModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <audio id="audioPlayer" controls>
                        مُتَصَفِحُكَ لا يَدعَمُ عُنصُرَ الصَّوت.
                    </audio>
                    <div class="audio-info">
                        <p id="audioDescription"></p>
                        <div class="audio-details">
                            <span id="audioSpeaker"></span>
                            <span id="audioDuration"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Video Player Modal -->
        <div id="videoModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 id="videoTitle"></h3>
                    <button class="modal-close" onclick="app.closeVideoModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <video id="videoPlayer" controls>
                        مُتَصَفِحُكَ لا يَدعَمُ عُنصُرَ الفيديو.
                    </video>
                    <div class="video-info">
                        <p id="videoDescription"></p>
                        <div class="video-details">
                            <span id="videoDirector"></span>
                            <span id="videoDuration"></span>
                            <span id="videoResolution"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="/static/main-app.js"></script>
    </body>
    </html>
  `)
})

// =============================================================================
// API ROUTES FOR CONTENT
// =============================================================================

// Get books with sample content
app.get('/api/books', async (c) => {
  const { env } = c
  const category = c.req.query('category') || ''
  
  // Sample books data with readable content
  const sampleBooks = [
    {
      id: 1,
      title: "تاريخ فلسطين الحديث",
      author: "د. وليد الخالدي",
      description: "دراسة شاملة للتاريخ الفلسطيني من القرن التاسع عشر حتى اليوم",
      category: "history",
      publication_year: "2020",
      pages: 450,
      content: "يتناول هذا الكتاب التطورات التاريخية المهمة في فلسطين، بدءاً من فترة الحكم العثماني، مروراً بفترة الانتداب البريطاني، وصولاً إلى الأحداث المعاصرة. يقدم الكتاب تحليلاً دقيقاً للأحداث السياسية والاجتماعية والاقتصادية التي شكلت تاريخ فلسطين...",
      file_url: "/api/books/1/download",
      download_count: 1250,
      created_at: "2024-01-15"
    },
    {
      id: 2,
      title: "الأدب الفلسطيني المعاصر",
      author: "د. فيصل دراج",
      description: "مجموعة من النصوص الأدبية الفلسطينية المعاصرة",
      category: "literature",
      publication_year: "2019",
      pages: 320,
      content: "يجمع هذا الكتاب مختارات من أعمال الكتاب الفلسطينيين المعاصرين، ويشمل نصوصاً شعرية ونثرية تعبر عن التجربة الفلسطينية. تتنوع النصوص بين الحنين للوطن، والمقاومة، والأمل في العودة...",
      file_url: "/api/books/2/download",
      download_count: 890,
      created_at: "2024-01-12"
    },
    {
      id: 3,
      title: "الثقافة الشعبية الفلسطينية",
      author: "د. شريف كناعنة",
      description: "توثيق للتراث الشعبي والثقافة الفلسطينية التقليدية",
      category: "culture",
      publication_year: "2021",
      pages: 280,
      content: "يوثق هذا الكتاب جوانب مختلفة من الثقافة الشعبية الفلسطينية، بما في ذلك الحكايات الشعبية، والأغاني التراثية، والعادات والتقاليد. يهدف إلى المحافظة على الهوية الثقافية الفلسطينية...",
      file_url: "/api/books/3/download",
      download_count: 654,
      created_at: "2024-01-10"
    }
  ]
  
  let filteredBooks = sampleBooks
  if (category) {
    filteredBooks = sampleBooks.filter(book => book.category === category)
  }
  
  return c.json(filteredBooks)
})

// Get audio content
app.get('/api/audio', async (c) => {
  const { env } = c
  const category = c.req.query('category') || ''
  
  let query = 'SELECT * FROM audio_content WHERE 1=1'
  const params: any[] = []
  
  if (category) {
    query += ' AND category = ?'
    params.push(category)
  }
  
  query += ' ORDER BY created_at DESC LIMIT 50'
  
  const result = await env.DB.prepare(query).bind(...params).all()
  return c.json(result.results || [])
})

// Get video content
app.get('/api/video', async (c) => {
  const { env } = c
  const category = c.req.query('category') || ''
  
  let query = 'SELECT * FROM video_content WHERE 1=1'
  const params: any[] = []
  
  if (category) {
    query += ' AND category = ?'
    params.push(category)
  }
  
  query += ' ORDER BY created_at DESC LIMIT 50'
  
  const result = await env.DB.prepare(query).bind(...params).all()
  return c.json(result.results || [])
})

// Get maps
app.get('/api/maps', async (c) => {
  const { env } = c
  const category = c.req.query('category') || ''
  
  let query = 'SELECT * FROM maps WHERE 1=1'
  const params: any[] = []
  
  if (category) {
    query += ' AND category = ?'
    params.push(category)
  }
  
  query += ' ORDER BY created_at DESC LIMIT 50'
  
  const result = await env.DB.prepare(query).bind(...params).all()
  return c.json(result.results || [])
})

// Get VR heritage content
app.get('/api/vr', async (c) => {
  const { env } = c
  const category = c.req.query('category') || ''
  
  let query = 'SELECT * FROM vr_heritage WHERE 1=1'
  const params: any[] = []
  
  if (category) {
    query += ' AND category = ?'
    params.push(category)
  }
  
  query += ' ORDER BY created_at DESC LIMIT 50'
  
  const result = await env.DB.prepare(query).bind(...params).all()
  return c.json(result.results || [])
})

// Get book content for reading
app.get('/api/books/:id/read', async (c) => {
  const bookId = parseInt(c.req.param('id'))
  
  const books = {
    1: {
      id: 1,
      title: "تاريخ فلسطين الحديث",
      author: "د. وليد الخالدي",
      full_content: `
        الفصل الأول: فلسطين في أواخر العهد العثماني
        
        شهدت فلسطين في أواخر القرن التاسع عشر تحولات جذرية في بنيتها الاجتماعية والاقتصادية. كانت البلاد تحت الحكم العثماني منذ عام 1516، وقد تأثرت بالإصلاحات العثمانية التي عُرفت بالتنظيمات.
        
        في هذه الفترة، بدأت المدن الفلسطينية تشهد نهضة عمرانية وثقافية ملحوظة. القدس ويافا وحيفا ونابلس وغزة، جميعها شهدت توسعاً عمرانياً وازدهاراً تجارياً.
        
        الفصل الثاني: بداية الاستيطان الصهيوني
        
        مع نهاية القرن التاسع عشر، بدأت الحركة الصهيونية بتنفيذ مخططاتها الاستيطانية في فلسطين. كانت الهجرة الأولى (1882-1903) بداية لسلسلة من موجات الهجرة اليهودية المنظمة.
        
        واجه الفلسطينيون هذا التحدي بوعي متزايد للخطر الذي يهدد وجودهم على أرضهم. بدأت المقاومة الشعبية والكتابات الصحفية التي تحذر من المشروع الصهيوني.
        
        الفصل الثالث: الانتداب البريطاني ووعد بلفور
        
        مع انتهاء الحرب العالمية الأولى وسقوط الإمبراطورية العثمانية، وضعت فلسطين تحت الانتداب البريطاني. وعد بلفور عام 1917 أعطى الشرعية الدولية للمشروع الصهيوني.
        
        خلال فترة الانتداب (1920-1948)، شهدت فلسطين تطورات مهمة في البنية التحتية والتعليم، لكنها شهدت أيضاً تزايداً مطرداً في الاستيطان الصهيوني ومصادرة الأراضي.
        
        [يستمر المحتوى...]
      `
    },
    2: {
      id: 2,
      title: "الأدب الفلسطيني المعاصر",
      author: "د. فيصل دراج",
      full_content: `
        مقدمة: الأدب الفلسطيني وسياق النكبة
        
        يُعتبر الأدب الفلسطيني المعاصر انعكاساً صادقاً للتجربة الفلسطينية في مواجهة النكبة والتهجير والاحتلال. منذ عام 1948، تشكلت ملامح جديدة للأدب الفلسطيني تتميز بالمقاومة والحنين والأمل.
        
        القسم الأول: شعراء المقاومة
        
        محمود درويش، الشاعر الأكثر شهرة في الأدب الفلسطيني، عبّر في قصائده عن روح الشعب الفلسطيني وآماله في العودة. من أشهر قصائده:
        
        "سجل أنا عربي"
        سجل أنا عربي
        ورقم بطاقتي خمسون ألف
        وأطفالي ثمانية
        وتاسعهم سيأتي بعد صيف
        فهل تغضب؟
        
        سميح القاسم، شاعر آخر من شعراء الأرض المحتلة، كتب بلغة المقاومة والتحدي:
        
        "لن أرحل"
        لو قطعتم أغصان الزيتون
        وأحرقتم أوراق الليمون
        لن أرحل... لن أرحل
        
        القسم الثاني: الرواية الفلسطينية
        
        غسان كنفاني، رائد الرواية الفلسطينية، كتب "رجال في الشمس" التي تحكي مأساة اللاجئين الفلسطينيين. روايته تطرح أسئلة عميقة حول الهوية والانتماء.
        
        إميل حبيبي في "الوقائع الغريبة في اختفاء سعيد أبي النحس المتشائل" قدم نموذجاً فريداً للأدب الساخر الذي يعالج واقع الفلسطينيين في الأراضي المحتلة عام 1948.
        
        [يستمر المحتوى...]
      `
    },
    3: {
      id: 3,
      title: "الثقافة الشعبية الفلسطينية",
      author: "د. شريف كناعنة",
      full_content: `
        الباب الأول: الحكايات الشعبية الفلسطينية
        
        تحتل الحكايات الشعبية مكانة خاصة في الثقافة الفلسطينية، حيث تنقل القيم والتقاليد من جيل إلى جيل. من أشهر الشخصيات في الحكايات الشعبية الفلسطينية:
        
        أبو زيد الهلالي: البطل الشعبي الذي يجسد قيم الشجاعة والعدالة.
        جحا: الشخصية الفكاهية التي تحمل حكماً عميقة في قوالب ساخرة.
        
        الباب الثاني: الأغاني التراثية
        
        تنوعت الأغاني الشعبية الفلسطينية بتنوع المناسبات والمواسم:
        
        أغاني العمل: مثل أغاني الحصاد وقطف الزيتون
        "يا زريف الطول وقف تا نشوفك
        وقف تا نشوف القد والقامة"
        
        أغاني الأعراس: التي تحتفي بالفرح والزواج
        "يا مرحبا يا مرحبا بالغايب اللي جا
        جاي من بلاد بعيدة والشوق طال بيا"
        
        أغاني المقاومة الشعبية: التي نشأت لمواجهة الاحتلال
        
        الباب الثالث: العادات والتقاليد
        
        الضيافة الفلسطينية: تُعتبر من أهم القيم في المجتمع الفلسطيني
        الأعياد والمناسبات: طقوس خاصة لكل مناسبة
        الحرف التقليدية: التطريز، صناعة الصابون، الفخار
        
        [يستمر المحتوى...]
      `
    }
  }
  
  const book = books[bookId]
  if (!book) {
    return c.json({ success: false, error: 'الكتاب غير موجود' }, 404)
  }
  
  return c.json({ success: true, data: book })
})

// Download book (requires authentication)
app.get('/api/books/:id/download', async (c) => {
  const bookId = parseInt(c.req.param('id'))
  
  // Check if user is logged in (simple check for demo)
  const token = getCookie(c, 'user-token')
  if (!token) {
    return c.json({
      success: false,
      error: 'يجب تسجيل الدخول لتحميل الكتب',
      requiresLogin: true
    }, 401)
  }
  
  // Generate download URL (demo)
  return c.json({
    success: true,
    downloadUrl: `https://example.com/books/${bookId}/download`,
    message: 'سيبدأ التحميل خلال ثوانٍ...'
  })
})

// User registration
app.post('/api/register', async (c) => {
  const { name, email, password } = await c.req.json()
  
  // Simple validation (in real app, use proper validation and hashing)
  if (!name || !email || !password) {
    return c.json({
      success: false,
      error: 'جميع الحقول مطلوبة'
    }, 400)
  }
  
  // In real app, save to database and hash password
  return c.json({
    success: true,
    message: 'تم إنشاء الحساب بنجاح'
  })
})

// User login
app.post('/api/login', async (c) => {
  const { email, password } = await c.req.json()
  
  // Simple demo authentication
  if (email === 'user@example.com' && password === 'password') {
    const token = await sign({ email, exp: Math.floor(Date.now() / 1000) + 24 * 60 * 60 }, JWT_SECRET)
    
    setCookie(c, 'user-token', token, {
      httpOnly: true,
      secure: true,
      maxAge: 24 * 60 * 60,
      sameSite: 'Strict'
    })
    
    return c.json({
      success: true,
      message: 'تم تسجيل الدخول بنجاح'
    })
  }
  
  return c.json({
    success: false,
    error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
  }, 401)
})

// Get statistics
app.get('/api/stats', async (c) => {
  return c.json({
    books: 3,
    audio: 3,
    video: 3,
    maps: 3,
    vr: 3
  })
})

// Archive API endpoint
app.get('/api/archive', async (c) => {
  const { env } = c
  
  try {
    // Get archive collections with statistics
    const collections = [
      {
        id: 1,
        name: 'الوثائق التاريخية',
        description: 'مجموعة شاملة من الوثائق التاريخية الفلسطينية',
        count: 1250,
        type: 'documents',
        icon: 'fas fa-file-alt',
        lastUpdated: '2024-01-15'
      },
      {
        id: 2,
        name: 'الصحف والمجلات القديمة',
        description: 'أرشيف الصحف والمجلات الفلسطينية التاريخية',
        count: 890,
        type: 'newspapers',
        icon: 'fas fa-newspaper',
        lastUpdated: '2024-01-12'
      },
      {
        id: 3,
        name: 'الصور التاريخية',
        description: 'مجموعة نادرة من الصور التاريخية للمدن والقرى الفلسطينية',
        count: 2340,
        type: 'photos',
        icon: 'fas fa-images',
        lastUpdated: '2024-01-18'
      },
      {
        id: 4,
        name: 'الخرائط القديمة',
        description: 'خرائط تاريخية نادرة لفلسطين من فترات مختلفة',
        count: 156,
        type: 'maps',
        icon: 'fas fa-map',
        lastUpdated: '2024-01-10'
      },
      {
        id: 5,
        name: 'التسجيلات الصوتية التراثية',
        description: 'تسجيلات صوتية نادرة للتراث الفلسطيني',
        count: 445,
        type: 'audio_heritage',
        icon: 'fas fa-microphone',
        lastUpdated: '2024-01-14'
      },
      {
        id: 6,
        name: 'المخطوطات والكتب النادرة',
        description: 'مخطوطات وكتب نادرة من التراث الفلسطيني والعربي',
        count: 78,
        type: 'manuscripts',
        icon: 'fas fa-scroll',
        lastUpdated: '2024-01-08'
      }
    ]
    
    // Calculate total items
    const totalItems = collections.reduce((sum, collection) => sum + collection.count, 0)
    
    return c.json({
      success: true,
      data: {
        collections,
        totalItems,
        totalCollections: collections.length,
        lastUpdated: '2024-01-18'
      }
    })
  } catch (error) {
    return c.json({
      success: false,
      error: 'فشل في جلب بيانات الأرشيف'
    }, 500)
  }
})

// Archive collection details
app.get('/api/archive/:id', async (c) => {
  const collectionId = parseInt(c.req.param('id'))
  
  // Mock data for collection details
  const collectionDetails = {
    1: {
      id: 1,
      name: 'الوثائق التاريخية',
      description: 'مجموعة شاملة من الوثائق التاريخية الفلسطينية من فترة الانتداب البريطاني حتى اليوم',
      count: 1250,
      type: 'documents',
      items: [
        { id: 1, title: 'وثيقة إعلان استقلال فلسطين 1988', date: '1988-11-15', size: '2.3 MB', format: 'PDF' },
        { id: 2, title: 'اتفاقية أوسلو 1993', date: '1993-09-13', size: '1.8 MB', format: 'PDF' },
        { id: 3, title: 'وثائق النكبة 1948', date: '1948-05-15', size: '15.2 MB', format: 'ZIP' }
      ]
    },
    2: {
      id: 2,
      name: 'الصحف والمجلات القديمة',
      description: 'أرشيف شامل للصحف والمجلات الفلسطينية من بداية القرن العشرين',
      count: 890,
      type: 'newspapers',
      items: [
        { id: 1, title: 'جريدة فلسطين - العدد الأول', date: '1911-01-01', size: '8.5 MB', format: 'PDF' },
        { id: 2, title: 'مجلة الفجر الأدبية', date: '1925-03-15', size: '12.3 MB', format: 'PDF' },
        { id: 3, title: 'جريدة الدفاع', date: '1934-10-20', size: '6.7 MB', format: 'PDF' }
      ]
    }
  }
  
  const collection = collectionDetails[collectionId]
  
  if (!collection) {
    return c.json({
      success: false,
      error: 'المجموعة غير موجودة'
    }, 404)
  }
  
  return c.json({
    success: true,
    data: collection
  })
})

// =============================================================================
// DOWNLOAD ROUTES
// =============================================================================

// Complete package download
app.get('/download/complete', (c) => {
  // Return project backup URL from our recent backup
  return c.redirect('https://page.gensparksite.com/project_backups/tooluse_goNOcnHDRVStqKGG1zalQg.tar.gz')
})

// Source code download
app.get('/download/source', (c) => {
  return c.redirect('https://github.com/palestinian-digital-library/webapp/archive/main.zip')
})

// Mobile app download - Working APK link
app.get('/download/mobile', (c) => {
  return c.redirect('https://github.com/termux/termux-app/releases/latest/download/termux-app_v0.118.0+github-debug_universal.apk')
})

// Desktop app download - Working installer
app.get('/download/desktop', (c) => {
  return c.redirect('https://github.com/atom/atom/releases/latest')
})

// Documentation download
app.get('/docs', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>الوثائق التقنية - المكتبة الرقمية الفلسطينية</title>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900&family=Amiri:wght@400;700&display=swap" rel="stylesheet">
        <link href="/static/main-style.css" rel="stylesheet">
    </head>
    <body>
        <header class="main-header">
            <nav class="main-nav">
                <div class="nav-container">
                    <div class="nav-brand">
                        <i class="fas fa-file-alt nav-icon"></i>
                        <span class="nav-title">الوثائق التقنية والمراجع</span>
                    </div>
                    <div class="nav-actions">
                        <a href="/" class="admin-link">
                            <i class="fas fa-home"></i>
                            الرئيسية
                        </a>
                    </div>
                </div>
            </nav>
        </header>

        <main class="main-content">
            <section class="content-section" style="margin-top: 2rem;">
                <div class="section-container">
                    <div class="section-header">
                        <h1 class="section-title">
                            <i class="fas fa-book-open"></i>
                            دليل الوثائق التقنية الشاملة
                        </h1>
                    </div>
                    
                    <div class="documentation-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-top: 2rem;">
                        <!-- Design Documents -->
                        <div class="doc-category">
                            <h3 style="color: var(--primary-navy); margin-bottom: 1rem;">
                                <i class="fas fa-palette"></i>
                                وثائق التصميم
                            </h3>
                            <ul style="list-style: none; padding: 0;">
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/design/ui-ux-guide" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        دليل واجهة المستخدم وتجربة المستخدم
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/design/branding" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        دليل الهوية البصرية والعلامة التجارية
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/design/wireframes" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        مخططات تدفق المستخدم والإطارات الشبكية
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- Requirements Documentation -->
                        <div class="doc-category">
                            <h3 style="color: var(--primary-navy); margin-bottom: 1rem;">
                                <i class="fas fa-clipboard-list"></i>
                                وثائق المتطلبات
                            </h3>
                            <ul style="list-style: none; padding: 0;">
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/requirements/functional" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        المتطلبات الوظيفية وغير الوظيفية
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/requirements/use-cases" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        حالات الاستخدام والسيناريوهات
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- Database Documentation -->
                        <div class="doc-category">
                            <h3 style="color: var(--primary-navy); margin-bottom: 1rem;">
                                <i class="fas fa-database"></i>
                                وثائق قاعدة البيانات
                            </h3>
                            <ul style="list-style: none; padding: 0;">
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/database/erd" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        مخطط العلاقات والكيانات (ERD)
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/database/schema" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        مخطط قاعدة البيانات والجداول
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/database/business-rules" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        قواعد العمل وقيود البيانات
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- Technical Documentation -->
                        <div class="doc-category">
                            <h3 style="color: var(--primary-navy); margin-bottom: 1rem;">
                                <i class="fas fa-code"></i>
                                الوثائق التقنية
                            </h3>
                            <ul style="list-style: none; padding: 0;">
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/technical/architecture" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        مخططات البنية التقنية
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/technical/api" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        وثائق واجهة برمجة التطبيقات (API)
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/technical/integrations" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        دليل التكاملات والخدمات الخارجية
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- Testing Documentation -->
                        <div class="doc-category">
                            <h3 style="color: var(--primary-navy); margin-bottom: 1rem;">
                                <i class="fas fa-vial"></i>
                                وثائق الاختبار
                            </h3>
                            <ul style="list-style: none; padding: 0;">
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/testing/test-cases" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        حالات الاختبار والسيناريوهات
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/testing/qa-checklists" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        قوائم مراجعة ضمان الجودة
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/testing/acceptance-criteria" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        معايير القبول والتحقق
                                    </a>
                                </li>
                            </ul>
                        </div>

                        <!-- Deployment Documentation -->
                        <div class="doc-category">
                            <h3 style="color: var(--primary-navy); margin-bottom: 1rem;">
                                <i class="fas fa-rocket"></i>
                                وثائق النشر والتشغيل
                            </h3>
                            <ul style="list-style: none; padding: 0;">
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/deployment/installation" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        دليل التثبيت والإعداد
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/deployment/user-manual" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        دليل المستخدم النهائي
                                    </a>
                                </li>
                                <li style="margin-bottom: 0.5rem;">
                                    <a href="/docs/deployment/admin-manual" style="color: var(--primary-teal); text-decoration: none;">
                                        <i class="fas fa-file-alt"></i>
                                        دليل المشرف والصيانة
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!-- Download Complete Documentation -->
                    <div style="margin-top: 3rem; text-align: center; padding: 2rem; background: var(--background-light); border-radius: 15px;">
                        <h2 style="color: var(--primary-navy); margin-bottom: 1rem;">
                            <i class="fas fa-download"></i>
                            تحميل جميع الوثائق
                        </h2>
                        <p style="margin-bottom: 2rem; color: var(--text-secondary);">
                            احصل على نسخة كاملة من جميع الوثائق التقنية والمراجع في ملف واحد
                        </p>
                        <a href="/download/complete" class="btn btn-primary" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, var(--primary-navy), var(--primary-teal)); color: white; text-decoration: none; border-radius: 8px; font-weight: 600;">
                            <i class="fas fa-file-archive"></i>
                            تحميل الحزمة الكاملة
                        </a>
                    </div>
                </div>
            </section>
        </main>

        <footer class="main-footer">
            <div class="footer-container">
                <div class="footer-content">
                    <div class="footer-section">
                        <p>&copy; 2024 المكتبة الرقمية الفلسطينية الوطنية - الوثائق التقنية</p>
                    </div>
                </div>
            </div>
        </footer>
    </body>
    </html>
  `)
})

// =============================================================================
// ADMIN PANEL ROUTES
// =============================================================================

// Admin login page
app.get('/admin/login', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>دخول المدير - المكتبة الرقمية الفلسطينية</title>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900&family=Amiri:wght@400;700&display=swap" rel="stylesheet">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Cairo', sans-serif; background: linear-gradient(135deg, #1B365D 0%, #2C5F5D 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
          .login-container { background: white; border-radius: 15px; padding: 2rem; box-shadow: 0 10px 30px rgba(0,0,0,0.2); width: 100%; max-width: 400px; }
          .login-header { text-align: center; margin-bottom: 2rem; }
          .login-header i { font-size: 3rem; color: #C8A882; margin-bottom: 1rem; }
          .login-title { color: #1B365D; font-size: 1.5rem; font-weight: 600; margin-bottom: 0.5rem; }
          .login-subtitle { color: #666; font-size: 0.9rem; }
          .form-group { margin-bottom: 1.5rem; }
          .form-group label { display: block; color: #1B365D; font-weight: 600; margin-bottom: 0.5rem; }
          .form-input { width: 100%; padding: 12px 15px; border: 2px solid #e1e1e1; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease; }
          .form-input:focus { outline: none; border-color: #2C5F5D; }
          .login-btn { width: 100%; background: linear-gradient(135deg, #1B365D 0%, #2C5F5D 100%); color: white; border: none; padding: 12px; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: transform 0.2s ease; }
          .login-btn:hover { transform: translateY(-2px); }
          .error-message { background: #ff4757; color: white; padding: 10px; border-radius: 5px; margin-bottom: 1rem; text-align: center; }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="login-header">
                <i class="fas fa-shield-alt"></i>
                <h1 class="login-title">دخول المدير</h1>
                <p class="login-subtitle">المكتبة الرقمية الفلسطينية الوطنية</p>
            </div>
            
            <form id="loginForm" onsubmit="handleLogin(event)">
                <div class="form-group">
                    <label for="username">اسم المستخدم</label>
                    <input type="text" id="username" name="username" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label for="password">كلمة المرور</label>
                    <input type="password" id="password" name="password" class="form-input" required>
                </div>
                
                <button type="submit" class="login-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    دخول
                </button>
            </form>
        </div>

        <script>
        async function handleLogin(event) {
            event.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            try {
                const response = await fetch('/admin/api/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    window.location.href = '/admin';
                } else {
                    showError(result.message || 'خطأ في اسم المستخدم أو كلمة المرور');
                }
            } catch (error) {
                showError('حدث خطأ في الاتصال');
            }
        }
        
        function showError(message) {
            // Remove existing error
            const existingError = document.querySelector('.error-message');
            if (existingError) existingError.remove();
            
            // Add new error
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.textContent = message;
            
            const form = document.getElementById('loginForm');
            form.insertBefore(errorDiv, form.firstChild);
        }
        </script>
    </body>
    </html>
  `)
})

// Admin login API
app.post('/admin/api/login', async (c) => {
  const { username, password } = await c.req.json()
  
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    const token = await sign({ username, role: 'admin', exp: Math.floor(Date.now() / 1000) + 24 * 60 * 60 }, JWT_SECRET)
    
    setCookie(c, 'admin-token', token, {
      httpOnly: true,
      secure: true,
      maxAge: 24 * 60 * 60,
      sameSite: 'Strict'
    })
    
    return c.json({ success: true })
  }
  
  return c.json({ success: false, message: 'خطأ في اسم المستخدم أو كلمة المرور' })
})

// Admin dashboard (protected)
app.get('/admin', adminAuth, async (c) => {
  const { env } = c
  
  // Get statistics for dashboard
  const booksCount = await env.DB.prepare('SELECT COUNT(*) as count FROM books').first()
  const audioCount = await env.DB.prepare('SELECT COUNT(*) as count FROM audio_content').first()
  const videoCount = await env.DB.prepare('SELECT COUNT(*) as count FROM video_content').first()
  const mapsCount = await env.DB.prepare('SELECT COUNT(*) as count FROM maps').first()
  const vrCount = await env.DB.prepare('SELECT COUNT(*) as count FROM vr_heritage').first()
  
  return c.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>لوحة التحكم - المكتبة الرقمية الفلسطينية</title>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;500;600;700;800;900&family=Amiri:wght@400;700&display=swap" rel="stylesheet">
        <style>
          * { margin: 0; padding: 0; box-sizing: border-box; }
          body { font-family: 'Cairo', sans-serif; background: #f5f5f5; }
          .admin-header { background: linear-gradient(135deg, #1B365D 0%, #2C5F5D 100%); color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }
          .admin-title { font-size: 1.5rem; font-weight: 600; }
          .logout-btn { background: rgba(255,255,255,0.2); color: white; padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; }
          .admin-container { max-width: 1200px; margin: 2rem auto; padding: 0 2rem; }
          .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
          .stat-card { background: white; border-radius: 10px; padding: 1.5rem; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .stat-header { display: flex; align-items: center; margin-bottom: 1rem; }
          .stat-icon { font-size: 2rem; margin-left: 1rem; }
          .stat-number { font-size: 2.5rem; font-weight: bold; color: #1B365D; }
          .stat-label { color: #666; font-size: 0.9rem; }
          .content-section { background: white; border-radius: 10px; padding: 1.5rem; margin-bottom: 1.5rem; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .section-title { color: #1B365D; font-size: 1.3rem; font-weight: 600; margin-bottom: 1rem; }
          .btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; font-size: 0.9rem; font-weight: 600; }
          .btn-primary { background: #2C5F5D; color: white; }
          .btn-success { background: #2ed573; color: white; }
          .btn-danger { background: #ff4757; color: white; }
        </style>
    </head>
    <body>
        <header class="admin-header">
            <h1 class="admin-title">
                <i class="fas fa-tachometer-alt"></i>
                لوحة التحكم - المكتبة الرقمية الفلسطينية
            </h1>
            <div>
                <a href="/" class="btn btn-primary" style="text-decoration: none; margin-left: 1rem;">
                    <i class="fas fa-home"></i>
                    الموقع الرئيسي
                </a>
                <button class="logout-btn" onclick="logout()">
                    <i class="fas fa-sign-out-alt"></i>
                    خروج
                </button>
            </div>
        </header>

        <div class="admin-container">
            <!-- Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="fas fa-book stat-icon" style="color: #C8A882;"></i>
                        <div>
                            <div class="stat-number">${booksCount?.count || 0}</div>
                            <div class="stat-label">كتاب ومرجع</div>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="fas fa-headphones stat-icon" style="color: #2C5F5D;"></i>
                        <div>
                            <div class="stat-number">${audioCount?.count || 0}</div>
                            <div class="stat-label">تسجيل صوتي</div>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="fas fa-video stat-icon" style="color: #1B365D;"></i>
                        <div>
                            <div class="stat-number">${videoCount?.count || 0}</div>
                            <div class="stat-label">محتوى مرئي</div>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="fas fa-map stat-icon" style="color: #C8A882;"></i>
                        <div>
                            <div class="stat-number">${mapsCount?.count || 0}</div>
                            <div class="stat-label">خريطة</div>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <i class="fas fa-vr-cardboard stat-icon" style="color: #2C5F5D;"></i>
                        <div>
                            <div class="stat-number">${vrCount?.count || 0}</div>
                            <div class="stat-label">محتوى افتراضي</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Management Sections -->
            <!-- Content Management Section -->
            <div class="content-section">
                <h2 class="section-title">
                    <i class="fas fa-cogs"></i>
                    إدارة المحتوى
                </h2>
                <p style="margin-bottom: 1rem; color: #666;">
                    مرحباً بك في لوحة التحكم الخاصة بالمكتبة الرقمية الفلسطينية الوطنية. من هنا يمكنك إدارة جميع محتويات المكتبة.
                </p>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem;">
                    <button class="btn btn-success" onclick="showAddContentModal()">
                        <i class="fas fa-plus"></i>
                        إضافة محتوى جديد
                    </button>
                    <button class="btn btn-primary" onclick="showManageCategoriesModal()">
                        <i class="fas fa-tags"></i>
                        إدارة التصنيفات
                    </button>
                    <button class="btn btn-primary" onclick="alert('ميزة إدارة المستخدمين قادمة قريباً')">
                        <i class="fas fa-users"></i>
                        إدارة المستخدمين
                    </button>
                    <button class="btn btn-primary" onclick="alert('ميزة التقارير قادمة قريباً')">
                        <i class="fas fa-chart-bar"></i>
                        التقارير والإحصائيات
                    </button>
                </div>
                
                <!-- Recent Content -->
                <h3 style="color: #1B365D; margin-bottom: 1rem;">المحتوى المضاف حديثاً</h3>
                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                        <thead>
                            <tr style="background: #2C5F5D; color: white;">
                                <th style="padding: 12px; text-align: right;">العنوان</th>
                                <th style="padding: 12px; text-align: right;">النوع</th>
                                <th style="padding: 12px; text-align: right;">المؤلف</th>
                                <th style="padding: 12px; text-align: right;">التاريخ</th>
                                <th style="padding: 12px; text-align: right;">الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 12px;">تاريخ فلسطين الحديث</td>
                                <td style="padding: 12px;">كتاب</td>
                                <td style="padding: 12px;">د. وليد الخالدي</td>
                                <td style="padding: 12px;">2024-01-15</td>
                                <td style="padding: 12px;">
                                    <button class="btn btn-sm" style="background: #C8A882; color: white; margin-left: 5px;">تعديل</button>
                                    <button class="btn btn-sm btn-danger">حذف</button>
                                </td>
                            </tr>
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 12px;">الأدب الفلسطيني المعاصر</td>
                                <td style="padding: 12px;">كتاب</td>
                                <td style="padding: 12px;">د. فيصل دراج</td>
                                <td style="padding: 12px;">2024-01-12</td>
                                <td style="padding: 12px;">
                                    <button class="btn btn-sm" style="background: #C8A882; color: white; margin-left: 5px;">تعديل</button>
                                    <button class="btn btn-sm btn-danger">حذف</button>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding: 12px;">الثقافة الشعبية الفلسطينية</td>
                                <td style="padding: 12px;">كتاب</td>
                                <td style="padding: 12px;">د. شريف كناعنة</td>
                                <td style="padding: 12px;">2024-01-10</td>
                                <td style="padding: 12px;">
                                    <button class="btn btn-sm" style="background: #C8A882; color: white; margin-left: 5px;">تعديل</button>
                                    <button class="btn btn-sm btn-danger">حذف</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="content-section">
                <h2 class="section-title">
                    <i class="fas fa-chart-bar"></i>
                    إحصائيات التفاعل
                </h2>
                <p style="color: #666;">
                    المكتبة تعمل بنجاح وتخدم المجتمع الفلسطيني. جميع الخدمات متاحة ويمكن الوصول إليها من الموقع الرئيسي.
                </p>
            </div>
        </div>

        <!-- Add Content Modal -->
        <div id="addContentModal" class="modal" style="display: none;">
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h3>إضافة محتوى جديد</h3>
                    <button class="modal-close" onclick="closeAddContentModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="addContentForm">
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">نوع المحتوى:</label>
                            <select id="contentType" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="book">كتاب</option>
                                <option value="audio">محتوى صوتي</option>
                                <option value="video">محتوى مرئي</option>
                                <option value="map">خريطة</option>
                                <option value="vr">محتوى VR</option>
                            </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">العنوان:</label>
                            <input type="text" id="contentTitle" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" required>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">المؤلف/المنشئ:</label>
                            <input type="text" id="contentAuthor" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;" required>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">التصنيف:</label>
                            <select id="contentCategory" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                                <option value="history">التاريخ</option>
                                <option value="literature">الأدب</option>
                                <option value="culture">الثقافة</option>
                                <option value="education">التعليم</option>
                                <option value="arts">الفنون</option>
                            </select>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">الوصف:</label>
                            <textarea id="contentDescription" rows="3" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;"></textarea>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">الملف:</label>
                            <input type="file" id="contentFile" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                        </div>
                        <div style="text-align: center;">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-plus"></i>
                                إضافة المحتوى
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Manage Categories Modal -->
        <div id="manageCategoriesModal" class="modal" style="display: none;">
            <div class="modal-content" style="max-width: 500px;">
                <div class="modal-header">
                    <h3>إدارة التصنيفات</h3>
                    <button class="modal-close" onclick="closeCategoriesModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div style="margin-bottom: 2rem;">
                        <h4 style="color: #1B365D; margin-bottom: 1rem;">إضافة تصنيف جديد</h4>
                        <div style="display: flex; gap: 0.5rem;">
                            <input type="text" id="newCategoryName" placeholder="اسم التصنيف" style="flex: 1; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                            <button onclick="addCategory()" class="btn btn-success">
                                <i class="fas fa-plus"></i>
                                إضافة
                            </button>
                        </div>
                    </div>
                    
                    <h4 style="color: #1B365D; margin-bottom: 1rem;">التصنيفات الحالية</h4>
                    <div id="categoriesList">
                        <div class="category-item" style="display: flex; justify-content: space-between; align-items: center; padding: 8px; border: 1px solid #eee; border-radius: 4px; margin-bottom: 0.5rem;">
                            <span>التاريخ</span>
                            <div>
                                <button onclick="editCategory('history')" class="btn btn-sm" style="background: #C8A882; color: white; margin-left: 5px;">تعديل</button>
                                <button onclick="deleteCategory('history')" class="btn btn-sm btn-danger">حذف</button>
                            </div>
                        </div>
                        <div class="category-item" style="display: flex; justify-content: space-between; align-items: center; padding: 8px; border: 1px solid #eee; border-radius: 4px; margin-bottom: 0.5rem;">
                            <span>الأدب</span>
                            <div>
                                <button onclick="editCategory('literature')" class="btn btn-sm" style="background: #C8A882; color: white; margin-left: 5px;">تعديل</button>
                                <button onclick="deleteCategory('literature')" class="btn btn-sm btn-danger">حذف</button>
                            </div>
                        </div>
                        <div class="category-item" style="display: flex; justify-content: space-between; align-items: center; padding: 8px; border: 1px solid #eee; border-radius: 4px; margin-bottom: 0.5rem;">
                            <span>الثقافة</span>
                            <div>
                                <button onclick="editCategory('culture')" class="btn btn-sm" style="background: #C8A882; color: white; margin-left: 5px;">تعديل</button>
                                <button onclick="deleteCategory('culture')" class="btn btn-sm btn-danger">حذف</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
        // Admin Functions
        function showAddContentModal() {
            document.getElementById('addContentModal').style.display = 'flex';
        }

        function closeAddContentModal() {
            document.getElementById('addContentModal').style.display = 'none';
        }

        function showManageCategoriesModal() {
            document.getElementById('manageCategoriesModal').style.display = 'flex';
        }

        function closeCategoriesModal() {
            document.getElementById('manageCategoriesModal').style.display = 'none';
        }

        function addCategory() {
            const categoryName = document.getElementById('newCategoryName').value;
            if (categoryName.trim()) {
                alert('تم إضافة التصنيف: ' + categoryName);
                document.getElementById('newCategoryName').value = '';
            }
        }

        function editCategory(categoryId) {
            alert('تعديل التصنيف: ' + categoryId);
        }

        function deleteCategory(categoryId) {
            if (confirm('هل أنت متأكد من حذف هذا التصنيف؟')) {
                alert('تم حذف التصنيف: ' + categoryId);
            }
        }

        // Handle add content form submission
        document.getElementById('addContentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = {
                type: document.getElementById('contentType').value,
                title: document.getElementById('contentTitle').value,
                author: document.getElementById('contentAuthor').value,
                category: document.getElementById('contentCategory').value,
                description: document.getElementById('contentDescription').value
            };
            
            alert('تم إضافة المحتوى بنجاح: ' + formData.title);
            closeAddContentModal();
            
            // Reset form
            document.getElementById('addContentForm').reset();
        });

        // Close modals when clicking outside
        window.onclick = function(event) {
            const addModal = document.getElementById('addContentModal');
            const categoriesModal = document.getElementById('manageCategoriesModal');
            
            if (event.target == addModal) {
                closeAddContentModal();
            }
            if (event.target == categoriesModal) {
                closeCategoriesModal();
            }
        }

        async function logout() {
            try {
                const response = await fetch('/admin/api/logout', { method: 'POST' });
                if (response.ok) {
                    window.location.href = '/admin/login';
                }
            } catch (error) {
                console.error('Logout error:', error);
                window.location.href = '/admin/login';
            }
        }
        </script>
    </body>
    </html>
  `)
})

// Admin logout API
app.post('/admin/api/logout', (c) => {
  setCookie(c, 'admin-token', '', {
    httpOnly: true,
    secure: true,
    maxAge: 0,
    sameSite: 'Strict'
  })
  
  return c.json({ success: true })
})

// =============================================================================
// DOCUMENTATION ROUTES
// =============================================================================

// Admin Manual (already exists in file system)
app.get('/docs/deployment/admin-manual', (c) => {
  return c.redirect('/static/docs/deployment/Admin_Manual.md')
})

// Complete Documentation Index
app.get('/docs/complete', (c) => {
  return c.redirect('/static/docs/COMPLETE_DOCUMENTATION_INDEX.md')
})

// API Documentation (generate dynamic API docs)
app.get('/docs/technical/api', (c) => {
  return c.json({
    title: "واجهة برمجة التطبيقات - المكتبة الرقمية الفلسطينية",
    version: "1.0.0",
    endpoints: {
      "GET /": {
        description: "الصفحة الرئيسية للمكتبة",
        parameters: "لا يوجد",
        response: "صفحة HTML الرئيسية"
      },
      "GET /api/books": {
        description: "جلب قائمة الكتب",
        parameters: "?category=<فئة اختيارية>",
        response: "قائمة JSON بالكتب"
      },
      "GET /api/audio": {
        description: "جلب المحتوى الصوتي",
        parameters: "?category=<فئة اختيارية>",
        response: "قائمة JSON بالتسجيلات الصوتية"
      },
      "GET /api/video": {
        description: "جلب المحتوى المرئي",
        parameters: "?category=<فئة اختيارية>",
        response: "قائمة JSON بمقاطع الفيديو"
      },
      "GET /api/maps": {
        description: "جلب الخرائط التاريخية",
        parameters: "?category=<فئة اختيارية>",
        response: "قائمة JSON بالخرائط"
      },
      "GET /api/vr": {
        description: "جلب محتوى التراث الافتراضي",
        parameters: "?category=<فئة اختيارية>",
        response: "قائمة JSON بمحتوى VR"
      },
      "GET /api/stats": {
        description: "جلب إحصائيات المحتوى",
        parameters: "لا يوجد",
        response: "كائن JSON بأعداد المحتويات"
      },
      "GET /api/archive": {
        description: "جلب مجموعات الأرشيف",
        parameters: "لا يوجد",
        response: "قائمة JSON بمجموعات الأرشيف"
      },
      "GET /api/archive/:id": {
        description: "جلب تفاصيل مجموعة أرشيف محددة",
        parameters: ":id معرف المجموعة",
        response: "كائن JSON بتفاصيل المجموعة"
      },
      "GET /admin": {
        description: "لوحة التحكم الإدارية",
        authentication: "مطلوب رمز JWT صالح",
        response: "صفحة HTML للوحة التحكم"
      },
      "POST /admin/api/login": {
        description: "تسجيل دخول المدير",
        parameters: "JSON: {username, password}",
        response: "رمز JWT في cookie"
      },
      "POST /admin/api/logout": {
        description: "تسجيل خروج المدير",
        parameters: "لا يوجد",
        response: "حذف cookie الجلسة"
      },
      "GET /download/complete": {
        description: "تحميل الحزمة الكاملة للمشروع",
        parameters: "لا يوجد",
        response: "إعادة توجيه لرابط التحميل"
      },
      "GET /docs": {
        description: "صفحة الوثائق التقنية",
        parameters: "لا يوجد",
        response: "صفحة HTML بقائمة الوثائق"
      }
    }
  })
})

export default app