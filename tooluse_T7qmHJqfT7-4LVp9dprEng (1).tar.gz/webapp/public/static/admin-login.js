// Admin Login Script
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('login-form');
    const messageDiv = document.getElementById('login-message');

    loginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        
        try {
            const response = await fetch('/admin/api/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });
            
            const result = await response.json();
            
            if (result.success) {
                messageDiv.innerHTML = '<div class="success">تم تسجيل الدخول بنجاح...</div>';
                setTimeout(() => {
                    window.location.href = '/admin/dashboard';
                }, 1000);
            } else {
                messageDiv.innerHTML = `<div class="error">${result.message}</div>`;
            }
        } catch (error) {
            messageDiv.innerHTML = '<div class="error">حدث خطأ في الاتصال</div>';
        }
    });

    // Add message styles
    const style = document.createElement('style');
    style.textContent = `
        .success { color: #10b981; text-align: center; margin-top: 1rem; }
        .error { color: #ef4444; text-align: center; margin-top: 1rem; }
    `;
    document.head.appendChild(style);
});