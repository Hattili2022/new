// Palestinian National Digital Library - Main Application

class PalestineLibraryApp {
    constructor() {
        this.currentData = {
            books: [],
            audio: [],
            video: [],
            maps: [],
            vr: [],
            archive: []
        };
        this.init();
    }

    async init() {
        await this.loadStats();
        this.setupEventListeners();
        // Load initial data for the first visible section
        this.loadSectionData('books');
    }

    async loadStats() {
        try {
            const response = await fetch('/api/stats');
            const stats = await response.json();
            
            document.getElementById('totalBooks').textContent = stats.books || 0;
            document.getElementById('totalAudio').textContent = stats.audio || 0;
            document.getElementById('totalVideos').textContent = stats.video || 0;
            document.getElementById('totalMaps').textContent = stats.maps || 0;
            
        } catch (error) {
            console.error('Error loading stats:', error);
        }
    }

    async loadSectionData(section) {
        try {
            const response = await fetch(`/api/${section}`);
            const data = await response.json();
            this.currentData[section] = data;
            this.renderSection(section);
        } catch (error) {
            console.error(`Error loading ${section} data:`, error);
        }
    }

    renderSection(section) {
        const grid = document.getElementById(`${section}Grid`);
        if (!grid) return;

        const data = this.currentData[section];
        
        if (!data || data.length === 0) {
            grid.innerHTML = '<div class="no-content">لا يوجد محتوى متاح حالياً</div>';
            return;
        }

        switch (section) {
            case 'books':
                this.renderBooks(data, grid);
                break;
            case 'audio':
                this.renderAudio(data, grid);
                break;
            case 'video':
                this.renderVideo(data, grid);
                break;
            case 'maps':
                this.renderMaps(data, grid);
                break;
            case 'vr':
                this.renderVR(data, grid);
                break;
            case 'archive':
                this.renderArchive(data, grid);
                break;
        }
    }

    renderBooks(books, container) {
        container.innerHTML = books.map(book => `
            <div class="content-card">
                <div class="card-header">
                    <i class="fas fa-book card-icon"></i>
                    <h3 class="card-title">${book.title}</h3>
                </div>
                <div class="card-body">
                    <p class="card-author">المؤلف: ${book.author}</p>
                    <p class="card-description">${book.description || 'وصف غير متوفر'}</p>
                    <div class="card-meta">
                        <span class="meta-item">
                            <i class="fas fa-tag"></i>
                            ${this.getCategoryName(book.category)}
                        </span>
                        ${book.publication_year ? `
                            <span class="meta-item">
                                <i class="fas fa-calendar"></i>
                                ${book.publication_year}
                            </span>
                        ` : ''}
                        ${book.pages ? `
                            <span class="meta-item">
                                <i class="fas fa-file-alt"></i>
                                ${book.pages} صفحة
                            </span>
                        ` : ''}
                    </div>
                </div>
                <div class="card-footer">
                    <div class="download-count">
                        <i class="fas fa-eye"></i>
                        ${book.download_count || 0} مشاهدة
                    </div>
                    <div class="book-actions">
                        <button class="btn btn-primary" onclick="event.stopPropagation(); app.readBook(${book.id})">
                            <i class="fas fa-book-open"></i>
                            قراءة
                        </button>
                        <button class="btn btn-success" onclick="event.stopPropagation(); app.downloadBook(${book.id})">
                            <i class="fas fa-download"></i>
                            تحميل
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderAudio(audioList, container) {
        container.innerHTML = audioList.map(audio => `
            <div class="content-card">
                <div class="card-header">
                    <i class="fas fa-headphones card-icon"></i>
                    <h3 class="card-title">${audio.title}</h3>
                </div>
                <div class="card-body">
                    ${audio.narrator ? `<p class="card-author">الراوي: ${audio.narrator}</p>` : ''}
                    <p class="card-description">${audio.description || 'وصف غير متوفر'}</p>
                    <div class="card-meta">
                        <span class="meta-item">
                            <i class="fas fa-tag"></i>
                            ${this.getCategoryName(audio.category)}
                        </span>
                        ${audio.duration ? `
                            <span class="meta-item">
                                <i class="fas fa-clock"></i>
                                ${audio.duration}
                            </span>
                        ` : ''}
                        ${audio.language ? `
                            <span class="meta-item">
                                <i class="fas fa-language"></i>
                                ${audio.language === 'ar' ? 'العربية' : audio.language}
                            </span>
                        ` : ''}
                    </div>
                </div>
                <div class="card-footer">
                    <div class="download-count">
                        <i class="fas fa-play"></i>
                        ${audio.download_count || 0} استماع
                    </div>
                    ${audio.file_url ? `
                        <button class="btn btn-primary" onclick="event.stopPropagation(); app.playAudio('${audio.file_url}', '${audio.title}', '${audio.description}', '${audio.narrator || ''}', '${audio.duration || ''}')">
                            <i class="fas fa-play"></i>
                            استماع
                        </button>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    renderVideo(videoList, container) {
        container.innerHTML = videoList.map(video => `
            <div class="content-card">
                <div class="card-header">
                    <i class="fas fa-video card-icon"></i>
                    <h3 class="card-title">${video.title}</h3>
                </div>
                <div class="card-body">
                    ${video.director ? `<p class="card-author">الإخراج: ${video.director}</p>` : ''}
                    <p class="card-description">${video.description || 'وصف غير متوفر'}</p>
                    <div class="card-meta">
                        <span class="meta-item">
                            <i class="fas fa-tag"></i>
                            ${this.getCategoryName(video.category)}
                        </span>
                        ${video.duration ? `
                            <span class="meta-item">
                                <i class="fas fa-clock"></i>
                                ${video.duration}
                            </span>
                        ` : ''}
                        ${video.resolution ? `
                            <span class="meta-item">
                                <i class="fas fa-video"></i>
                                ${video.resolution}
                            </span>
                        ` : ''}
                    </div>
                </div>
                <div class="card-footer">
                    <div class="download-count">
                        <i class="fas fa-eye"></i>
                        ${video.download_count || 0} مشاهدة
                    </div>
                    ${video.file_url ? `
                        <button class="btn btn-primary" onclick="event.stopPropagation(); app.playVideo('${video.file_url}', '${video.title}', '${video.description}', '${video.director || ''}', '${video.duration || ''}', '${video.resolution || ''}')">
                            <i class="fas fa-play"></i>
                            مشاهدة
                        </button>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    renderMaps(mapsList, container) {
        container.innerHTML = mapsList.map(map => `
            <div class="content-card">
                <div class="card-header">
                    <i class="fas fa-map-marked-alt card-icon"></i>
                    <h3 class="card-title">${map.title}</h3>
                </div>
                <div class="card-body">
                    <p class="card-description">${map.description || 'وصف غير متوفر'}</p>
                    <div class="card-meta">
                        <span class="meta-item">
                            <i class="fas fa-tag"></i>
                            ${this.getCategoryName(map.category)}
                        </span>
                        ${map.year ? `
                            <span class="meta-item">
                                <i class="fas fa-calendar"></i>
                                ${map.year}
                            </span>
                        ` : ''}
                        ${map.region ? `
                            <span class="meta-item">
                                <i class="fas fa-map-marker-alt"></i>
                                ${map.region}
                            </span>
                        ` : ''}
                    </div>
                </div>
                <div class="card-footer">
                    <div class="download-count">
                        <i class="fas fa-eye"></i>
                        ${map.download_count || 0} مشاهدة
                    </div>
                    ${map.map_url ? `
                        <button class="btn btn-primary" onclick="event.stopPropagation(); app.viewMap('${map.map_url}', '${map.title}')">
                            <i class="fas fa-search-plus"></i>
                            عرض
                        </button>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    renderVR(vrList, container) {
        container.innerHTML = vrList.map(vr => `
            <div class="content-card">
                <div class="card-header">
                    <i class="fas fa-vr-cardboard card-icon"></i>
                    <h3 class="card-title">${vr.title}</h3>
                </div>
                <div class="card-body">
                    <p class="card-description">${vr.description || 'وصف غير متوفر'}</p>
                    <div class="card-meta">
                        <span class="meta-item">
                            <i class="fas fa-tag"></i>
                            ${this.getCategoryName(vr.category)}
                        </span>
                        ${vr.location ? `
                            <span class="meta-item">
                                <i class="fas fa-map-marker-alt"></i>
                                ${vr.location}
                            </span>
                        ` : ''}
                        ${vr.technology ? `
                            <span class="meta-item">
                                <i class="fas fa-cogs"></i>
                                ${vr.technology}
                            </span>
                        ` : ''}
                    </div>
                </div>
                <div class="card-footer">
                    <div class="download-count">
                        <i class="fas fa-eye"></i>
                        ${vr.visit_count || 0} زيارة
                    </div>
                    ${vr.vr_url ? `
                        <button class="btn btn-primary" onclick="event.stopPropagation(); app.launchVR('${vr.vr_url}', '${vr.title}')">
                            <i class="fas fa-play"></i>
                            تشغيل
                        </button>
                    ` : ''}
                </div>
            </div>
        `).join('');
    }

    getCategoryName(category) {
        const categoryNames = {
            'history': 'التاريخ',
            'literature': 'الأدب',
            'culture': 'الثقافة',
            'education': 'التعليم',
            'speeches': 'الخطب',
            'poetry': 'الشعر',
            'interviews': 'المقابلات',
            'folk_music': 'التراث الموسيقي',
            'documentaries': 'الأفلام الوثائقية',
            'cultural': 'الثقافة والتراث',
            'children': 'برامج الأطفال',
            'historical': 'تاريخي',
            'modern': 'معاصر',
            'religious': 'ديني',
            'administrative': 'إداري',
            'archaeological': 'أثري'
        };
        return categoryNames[category] || category || 'عام';
    }

    scrollToSection(sectionId) {
        const element = document.getElementById(sectionId);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
            
            // Load section data if not already loaded
            const sectionName = sectionId.replace('-section', '');
            if (this.currentData[sectionName].length === 0) {
                this.loadSectionData(sectionName);
            }
        }
    }

    filterContent(section) {
        const categorySelect = document.getElementById(`${section}Category`);
        const selectedCategory = categorySelect?.value || '';
        
        // Reload data with filter
        this.loadFilteredData(section, selectedCategory);
    }

    async loadFilteredData(section, category = '') {
        try {
            let url = `/api/${section}`;
            if (category) {
                url += `?category=${encodeURIComponent(category)}`;
            }
            
            const response = await fetch(url);
            const data = await response.json();
            this.currentData[section] = data;
            this.renderSection(section);
        } catch (error) {
            console.error(`Error loading filtered ${section} data:`, error);
        }
    }

    setupEventListeners() {
        // Handle clicks outside download menu
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.download-dropdown')) {
                this.closeDownloadMenu();
            }
        });

        // Handle modal close on outside click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeAllModals();
            }
        });

        // Handle ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
        
        // Prevent modal actions from interfering with navigation
        document.addEventListener('click', (e) => {
            // Allow normal navigation for nav items and regular links
            if (e.target.closest('.nav-item') || e.target.closest('a[href]')) {
                // Don't prevent normal navigation
                return;
            }
        });
        
        // Ensure all modals are closed on page load
        setTimeout(() => {
            this.closeAllModals();
        }, 100);
    }

    toggleDownloadMenu() {
        const menu = document.getElementById('downloadMenu');
        if (menu) {
            menu.classList.toggle('show');
        }
    }

    closeDownloadMenu() {
        const menu = document.getElementById('downloadMenu');
        if (menu) {
            menu.classList.remove('show');
        }
    }

    playAudio(url, title, description, speaker, duration) {
        // First close any existing modals
        this.closeAllModals();
        
        const modal = document.getElementById('audioModal');
        const player = document.getElementById('audioPlayer');
        const titleEl = document.getElementById('audioTitle');
        const descEl = document.getElementById('audioDescription');
        const speakerEl = document.getElementById('audioSpeaker');
        const durationEl = document.getElementById('audioDuration');

        if (modal && player && titleEl && descEl) {
            titleEl.textContent = title || 'عنوان غير متوفر';
            descEl.textContent = description || 'وصف غير متوفر';
            if (speakerEl) speakerEl.textContent = speaker ? `الراوي: ${speaker}` : '';
            if (durationEl) durationEl.textContent = duration ? `المدة: ${duration}` : '';
            
            player.src = url || '';
            modal.style.display = 'flex';
            
            // Ensure modal can be closed by clicking outside
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeAudioModal();
                }
            });
        }
    }

    closeAudioModal() {
        const modal = document.getElementById('audioModal');
        const player = document.getElementById('audioPlayer');
        
        if (modal) {
            modal.style.display = 'none';
        }
        if (player) {
            player.pause();
            player.currentTime = 0;
            player.src = ''; // Clear the source
        }
    }

    playVideo(url, title, description, director, duration, resolution) {
        // First close any existing modals
        this.closeAllModals();
        
        const modal = document.getElementById('videoModal');
        const player = document.getElementById('videoPlayer');
        const titleEl = document.getElementById('videoTitle');
        const descEl = document.getElementById('videoDescription');
        const directorEl = document.getElementById('videoDirector');
        const durationEl = document.getElementById('videoDuration');
        const resolutionEl = document.getElementById('videoResolution');

        if (modal && player && titleEl && descEl) {
            titleEl.textContent = title || 'عنوان غير متوفر';
            descEl.textContent = description || 'وصف غير متوفر';
            if (directorEl) directorEl.textContent = director ? `الإخراج: ${director}` : '';
            if (durationEl) durationEl.textContent = duration ? `المدة: ${duration}` : '';
            if (resolutionEl) resolutionEl.textContent = resolution ? `الجودة: ${resolution}` : '';
            
            player.src = url || '';
            modal.style.display = 'flex';
            
            // Ensure modal can be closed by clicking outside
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeVideoModal();
                }
            });
        }
    }

    closeVideoModal() {
        const modal = document.getElementById('videoModal');
        const player = document.getElementById('videoPlayer');
        
        if (modal) {
            modal.style.display = 'none';
        }
        if (player) {
            player.pause();
            player.currentTime = 0;
            player.src = ''; // Clear the source
        }
    }
    
    // Close all modals function
    closeAllModals() {
        this.closeAudioModal();
        this.closeVideoModal();
        this.closeCollectionModal();
        this.closeBookReader();
        this.closeLoginModal();
        this.closeDownloadMenu();
    }

    downloadFile(url, filename) {
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.target = '_blank';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    viewMap(url, title) {
        window.open(url, '_blank', 'width=1000,height=800,scrollbars=yes,resizable=yes');
    }

    launchVR(url, title) {
        window.open(url, '_blank', 'width=1200,height=800,scrollbars=yes,resizable=yes');
    }

    // Archive functionality
    async showArchive() {
        // Hide other sections
        const sections = ['books-section', 'audio-section', 'video-section', 'maps-section', 'vr-section'];
        sections.forEach(sectionId => {
            const section = document.getElementById(sectionId);
            if (section) section.style.display = 'none';
        });

        // Show archive section
        const archiveSection = document.getElementById('archive-section');
        if (archiveSection) {
            archiveSection.style.display = 'block';
            archiveSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        // Load archive data
        await this.loadArchiveData();
    }

    async loadArchiveData() {
        try {
            const response = await fetch('/api/archive');
            const result = await response.json();
            
            if (result.success) {
                this.currentData.archive = result.data.collections;
                this.updateArchiveStats(result.data);
                this.renderArchive(this.currentData.archive, document.getElementById('archiveGrid'));
            }
        } catch (error) {
            console.error('Error loading archive data:', error);
        }
    }

    updateArchiveStats(archiveData) {
        const totalCollectionsEl = document.getElementById('totalCollections');
        const totalItemsEl = document.getElementById('totalItems');
        
        if (totalCollectionsEl) {
            totalCollectionsEl.textContent = archiveData.totalCollections || 0;
        }
        if (totalItemsEl) {
            totalItemsEl.textContent = archiveData.totalItems || 0;
        }
    }

    renderArchive(collections, container) {
        if (!container) return;

        if (!collections || collections.length === 0) {
            container.innerHTML = '<div class="no-content">لا توجد مجموعات أرشيفية متاحة حالياً</div>';
            return;
        }

        container.innerHTML = collections.map(collection => `
            <div class="content-card archive-card">
                <div class="card-header">
                    <i class="${collection.icon || 'fas fa-archive'} card-icon"></i>
                    <h3 class="card-title">${collection.name}</h3>
                </div>
                <div class="card-body">
                    <p class="card-description">${collection.description}</p>
                    <div class="card-meta">
                        <span class="meta-item">
                            <i class="fas fa-layer-group"></i>
                            ${collection.count} عنصر
                        </span>
                        <span class="meta-item">
                            <i class="fas fa-tag"></i>
                            ${collection.type}
                        </span>
                        <span class="meta-item">
                            <i class="fas fa-calendar"></i>
                            آخر تحديث: ${collection.lastUpdated}
                        </span>
                    </div>
                </div>
                <div class="card-footer">
                    <button class="btn btn-primary" onclick="app.viewArchiveCollection(${collection.id})">
                        <i class="fas fa-eye"></i>
                        استعراض المجموعة
                    </button>
                    <button class="btn btn-secondary" onclick="app.downloadCollection(${collection.id})">
                        <i class="fas fa-download"></i>
                        تحميل
                    </button>
                </div>
            </div>
        `).join('');
    }

    async viewArchiveCollection(collectionId) {
        try {
            const response = await fetch(`/api/archive/${collectionId}`);
            const result = await response.json();
            
            if (result.success) {
                this.showCollectionModal(result.data);
            } else {
                alert('فشل في جلب تفاصيل المجموعة');
            }
        } catch (error) {
            console.error('Error loading collection details:', error);
            alert('حدث خطأ أثناء جلب تفاصيل المجموعة');
        }
    }

    showCollectionModal(collection) {
        // Create modal dynamically if it doesn't exist
        let modal = document.getElementById('collectionModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'collectionModal';
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content collection-modal">
                    <div class="modal-header">
                        <h3 id="collectionTitle"></h3>
                        <button class="modal-close" onclick="app.closeCollectionModal()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <p id="collectionDescription"></p>
                        <div id="collectionItems"></div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }

        // Update modal content
        document.getElementById('collectionTitle').textContent = collection.name;
        document.getElementById('collectionDescription').textContent = collection.description;
        
        const itemsContainer = document.getElementById('collectionItems');
        if (collection.items && collection.items.length > 0) {
            itemsContainer.innerHTML = `
                <h4 style="margin: 1rem 0; color: var(--primary-navy);">عناصر المجموعة:</h4>
                <div class="collection-items">
                    ${collection.items.map(item => `
                        <div class="collection-item">
                            <div class="item-info">
                                <h5 style="margin: 0; color: var(--primary-teal);">${item.title}</h5>
                                <div class="item-meta">
                                    <span><i class="fas fa-calendar"></i> ${item.date}</span>
                                    <span><i class="fas fa-file"></i> ${item.size}</span>
                                    <span><i class="fas fa-file-alt"></i> ${item.format}</span>
                                </div>
                            </div>
                            <button class="btn btn-sm btn-primary" onclick="app.downloadCollectionItem(${collection.id}, ${item.id})">
                                <i class="fas fa-download"></i>
                                تحميل
                            </button>
                        </div>
                    `).join('')}
                </div>
            `;
        } else {
            itemsContainer.innerHTML = '<p style="color: var(--text-secondary);">لا توجد عناصر متاحة في هذه المجموعة حالياً</p>';
        }

        modal.style.display = 'flex';
    }

    closeCollectionModal() {
        const modal = document.getElementById('collectionModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    downloadCollection(collectionId) {
        alert(`جاري تحضير تحميل المجموعة رقم ${collectionId}...`);
        // Here you would typically trigger the actual download
    }

    downloadCollectionItem(collectionId, itemId) {
        alert(`جاري تحميل العنصر رقم ${itemId} من المجموعة ${collectionId}...`);
        // Here you would typically trigger the actual download
    }

    // Book Reading Functions
    async readBook(bookId) {
        try {
            const response = await fetch(`/api/books/${bookId}/read`);
            const result = await response.json();
            
            if (result.success) {
                this.showBookReader(result.data);
            } else {
                alert('فشل في جلب محتوى الكتاب');
            }
        } catch (error) {
            console.error('Error reading book:', error);
            alert('حدث خطأ أثناء فتح الكتاب');
        }
    }

    showBookReader(book) {
        // Create or show book reader modal
        let modal = document.getElementById('bookReaderModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'bookReaderModal';
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content book-reader" style="max-width: 900px; max-height: 90vh; overflow-y: auto;">
                    <div class="modal-header" style="position: sticky; top: 0; background: var(--primary-navy); color: white; z-index: 10;">
                        <h3 id="bookReaderTitle"></h3>
                        <button class="modal-close" onclick="app.closeBookReader()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body" style="padding: 2rem; line-height: 1.8; font-size: 1.1rem;">
                        <div id="bookReaderAuthor" style="color: var(--text-secondary); margin-bottom: 2rem; font-style: italic;"></div>
                        <div id="bookReaderContent" style="white-space: pre-line;"></div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }

        // Update modal content
        document.getElementById('bookReaderTitle').textContent = book.title;
        document.getElementById('bookReaderAuthor').textContent = `المؤلف: ${book.author}`;
        document.getElementById('bookReaderContent').textContent = book.full_content;
        
        modal.style.display = 'flex';
    }

    closeBookReader() {
        const modal = document.getElementById('bookReaderModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    async downloadBook(bookId) {
        try {
            const response = await fetch(`/api/books/${bookId}/download`);
            const result = await response.json();
            
            if (result.success) {
                alert(result.message);
                // In real app, would redirect to download URL
                window.open(result.downloadUrl, '_blank');
            } else if (result.requiresLogin) {
                this.showLoginModal();
            } else {
                alert(result.error);
            }
        } catch (error) {
            console.error('Error downloading book:', error);
            alert('حدث خطأ أثناء محاولة التحميل');
        }
    }

    showLoginModal() {
        // Create or show login modal
        let modal = document.getElementById('loginModal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'loginModal';
            modal.className = 'modal';
            modal.innerHTML = `
                <div class="modal-content" style="max-width: 400px;">
                    <div class="modal-header">
                        <h3>تسجيل الدخول</h3>
                        <button class="modal-close" onclick="app.closeLoginModal()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div id="loginTabs" style="display: flex; margin-bottom: 2rem; border-bottom: 1px solid #eee;">
                            <button id="loginTab" class="tab-button active" onclick="app.showLoginTab()" style="flex: 1; padding: 10px; border: none; background: none; cursor: pointer; border-bottom: 2px solid var(--primary-teal); color: var(--primary-teal);">
                                تسجيل الدخول
                            </button>
                            <button id="registerTab" class="tab-button" onclick="app.showRegisterTab()" style="flex: 1; padding: 10px; border: none; background: none; cursor: pointer; color: var(--text-secondary);">
                                إنشاء حساب
                            </button>
                        </div>
                        
                        <!-- Login Form -->
                        <div id="loginForm">
                            <form onsubmit="app.handleLogin(event)">
                                <div style="margin-bottom: 1rem;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">البريد الإلكتروني:</label>
                                    <input type="email" id="loginEmail" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;" required>
                                </div>
                                <div style="margin-bottom: 1.5rem;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">كلمة المرور:</label>
                                    <input type="password" id="loginPassword" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;" required>
                                </div>
                                <button type="submit" class="btn btn-primary" style="width: 100%;">
                                    <i class="fas fa-sign-in-alt"></i>
                                    تسجيل الدخول
                                </button>
                            </form>
                            <p style="margin-top: 1rem; text-align: center; color: var(--text-secondary); font-size: 0.9rem;">
                                للتجربة: user@example.com / password
                            </p>
                        </div>
                        
                        <!-- Register Form -->
                        <div id="registerForm" style="display: none;">
                            <form onsubmit="app.handleRegister(event)">
                                <div style="margin-bottom: 1rem;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">الاسم الكامل:</label>
                                    <input type="text" id="registerName" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;" required>
                                </div>
                                <div style="margin-bottom: 1rem;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">البريد الإلكتروني:</label>
                                    <input type="email" id="registerEmail" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;" required>
                                </div>
                                <div style="margin-bottom: 1.5rem;">
                                    <label style="display: block; margin-bottom: 0.5rem; font-weight: 600;">كلمة المرور:</label>
                                    <input type="password" id="registerPassword" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px;" required>
                                </div>
                                <button type="submit" class="btn btn-success" style="width: 100%;">
                                    <i class="fas fa-user-plus"></i>
                                    إنشاء حساب
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(modal);
        }
        
        modal.style.display = 'flex';
    }

    closeLoginModal() {
        const modal = document.getElementById('loginModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    showLoginTab() {
        document.getElementById('loginForm').style.display = 'block';
        document.getElementById('registerForm').style.display = 'none';
        document.getElementById('loginTab').className = 'tab-button active';
        document.getElementById('registerTab').className = 'tab-button';
        document.getElementById('loginTab').style.borderBottom = '2px solid var(--primary-teal)';
        document.getElementById('loginTab').style.color = 'var(--primary-teal)';
        document.getElementById('registerTab').style.borderBottom = 'none';
        document.getElementById('registerTab').style.color = 'var(--text-secondary)';
    }

    showRegisterTab() {
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('registerForm').style.display = 'block';
        document.getElementById('loginTab').className = 'tab-button';
        document.getElementById('registerTab').className = 'tab-button active';
        document.getElementById('registerTab').style.borderBottom = '2px solid var(--primary-teal)';
        document.getElementById('registerTab').style.color = 'var(--primary-teal)';
        document.getElementById('loginTab').style.borderBottom = 'none';
        document.getElementById('loginTab').style.color = 'var(--text-secondary)';
    }

    async handleLogin(event) {
        event.preventDefault();
        
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        
        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert(result.message);
                this.closeLoginModal();
            } else {
                alert(result.error);
            }
        } catch (error) {
            console.error('Login error:', error);
            alert('حدث خطأ أثناء تسجيل الدخول');
        }
    }

    async handleRegister(event) {
        event.preventDefault();
        
        const name = document.getElementById('registerName').value;
        const email = document.getElementById('registerEmail').value;
        const password = document.getElementById('registerPassword').value;
        
        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, password })
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert(result.message);
                this.showLoginTab();
            } else {
                alert(result.error);
            }
        } catch (error) {
            console.error('Register error:', error);
            alert('حدث خطأ أثناء إنشاء الحساب');
        }
    }
}

// Initialize the application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.app = new PalestineLibraryApp();
});

// Global functions for onclick handlers
function toggleDownloadMenu() {
    if (window.app) {
        window.app.toggleDownloadMenu();
    }
}