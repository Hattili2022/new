// Palestinian Digital Library - Admin Dashboard Application

class AdminDashboard {
    constructor() {
        this.currentSection = 'dashboard';
        this.categories = [];
        this.init();
    }

    async init() {
        await this.checkAuth();
        this.renderDashboard();
        this.setupEventListeners();
        this.loadInitialData();
    }

    async checkAuth() {
        // Check if user is authenticated
        try {
            const response = await fetch('/admin/api/categories');
            if (!response.ok) {
                window.location.href = '/admin/login';
                return;
            }
        } catch (error) {
            window.location.href = '/admin/login';
            return;
        }
    }

    renderDashboard() {
        const app = document.getElementById('admin-app');
        
        app.innerHTML = `
            <div class="admin-layout">
                ${this.renderSidebar()}
                ${this.renderMainContent()}
            </div>
        `;
    }

    renderSidebar() {
        return `
            <aside class="admin-sidebar">
                <div class="sidebar-header">
                    <h2>لوحة التحكم</h2>
                    <p>المكتبة الوطنية الفلسطينية</p>
                </div>
                
                <nav class="sidebar-nav">
                    <ul>
                        <li class="nav-item">
                            <a href="#dashboard" class="nav-link active" onclick="admin.showSection('dashboard')">
                                <i class="fas fa-tachometer-alt"></i>
                                الرئيسية
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#books" class="nav-link" onclick="admin.showSection('books')">
                                <i class="fas fa-book"></i>
                                إدارة الكتب
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#categories" class="nav-link" onclick="admin.showSection('categories')">
                                <i class="fas fa-tags"></i>
                                إدارة التصنيفات
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#submissions" class="nav-link" onclick="admin.showSection('submissions')">
                                <i class="fas fa-inbox"></i>
                                المساهمات المعلقة
                                <span class="nav-badge" id="submissions-badge">0</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#documents" class="nav-link" onclick="admin.showSection('documents')">
                                <i class="fas fa-file-alt"></i>
                                إدارة الوثائق
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#strategic" class="nav-link" onclick="admin.showSection('strategic')">
                                <i class="fas fa-flag"></i>
                                المحتوى الاستراتيجي
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#users" class="nav-link" onclick="admin.showSection('users')">
                                <i class="fas fa-users"></i>
                                إدارة المستخدمين
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#settings" class="nav-link" onclick="admin.showSection('settings')">
                                <i class="fas fa-cog"></i>
                                الإعدادات
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link" onclick="admin.logout()">
                                <i class="fas fa-sign-out-alt"></i>
                                تسجيل الخروج
                            </a>
                        </li>
                    </ul>
                </nav>
            </aside>
        `;
    }

    renderMainContent() {
        return `
            <main class="admin-main">
                <header class="admin-header">
                    <h1 class="page-title" id="page-title">لوحة التحكم الرئيسية</h1>
                    <div class="admin-actions">
                        <button class="btn btn-primary" onclick="window.open('/', '_blank')">
                            <i class="fas fa-external-link-alt"></i> عرض الموقع
                        </button>
                    </div>
                </header>
                
                <div class="admin-content">
                    <div id="dashboard-section" class="content-section active">
                        ${this.renderDashboardContent()}
                    </div>
                    <div id="books-section" class="content-section">
                        ${this.renderBooksContent()}
                    </div>
                    <div id="categories-section" class="content-section">
                        ${this.renderCategoriesContent()}
                    </div>
                    <div id="submissions-section" class="content-section">
                        ${this.renderSubmissionsContent()}
                    </div>
                    <div id="documents-section" class="content-section">
                        ${this.renderDocumentsContent()}
                    </div>
                    <div id="strategic-section" class="content-section">
                        ${this.renderStrategicContent()}
                    </div>
                    <div id="users-section" class="content-section">
                        ${this.renderUsersContent()}
                    </div>
                    <div id="settings-section" class="content-section">
                        ${this.renderSettingsContent()}
                    </div>
                </div>
            </main>
        `;
    }

    renderDashboardContent() {
        return `
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-title">إجمالي الكتب</div>
                        <div class="stat-icon">
                            <i class="fas fa-book"></i>
                        </div>
                    </div>
                    <div class="stat-value" id="total-books">-</div>
                    <div class="stat-description">كتاب منشور في المكتبة</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-title">المساهمات المعلقة</div>
                        <div class="stat-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                    </div>
                    <div class="stat-value" id="pending-submissions">-</div>
                    <div class="stat-description">مساهمة بانتظار المراجعة</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-title">القرى الفلسطينية</div>
                        <div class="stat-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                    </div>
                    <div class="stat-value" id="total-villages">-</div>
                    <div class="stat-description">قرية في النظام</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-title">المخطوطات المرقمنة</div>
                        <div class="stat-icon">
                            <i class="fas fa-scroll"></i>
                        </div>
                    </div>
                    <div class="stat-value" id="digitized-manuscripts">-</div>
                    <div class="stat-description">من إجمالي المجموعة</div>
                </div>
            </div>
            
            <div class="data-table-container">
                <div class="table-header">
                    <h3 class="table-title">آخر الأنشطة</h3>
                </div>
                <div id="recent-activities" class="loading">
                    جاري تحميل الأنشطة الأخيرة...
                </div>
            </div>
        `;
    }

    renderBooksContent() {
        return `
            <div class="form-container">
                <div class="form-header">
                    <h3 class="form-title">إضافة كتاب جديد</h3>
                </div>
                
                <form id="add-book-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">عنوان الكتاب</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">المؤلف</label>
                            <input type="text" class="form-control" name="author" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">سنة النشر</label>
                            <input type="number" class="form-control" name="year" required min="1800" max="2024">
                        </div>
                        <div class="form-group">
                            <label class="form-label">التصنيف الرئيسي</label>
                            <select class="form-control" name="category_id" id="book-category" required>
                                <option value="">اختر التصنيف</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">التصنيف الفرعي</label>
                            <select class="form-control" name="subcategory" id="book-subcategory" required>
                                <option value="">اختر التصنيف الفرعي</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">رابط الملف (اختياري)</label>
                            <input type="url" class="form-control" name="file_url" placeholder="https://...">
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i> إضافة الكتاب
                    </button>
                </form>
            </div>
            
            <div class="data-table-container">
                <div class="table-header">
                    <h3 class="table-title">قائمة الكتب</h3>
                    <div class="table-actions">
                        <input type="text" class="search-box" placeholder="البحث في الكتب..." id="books-search">
                        <button class="btn btn-secondary" onclick="admin.loadBooks()">
                            <i class="fas fa-refresh"></i> تحديث
                        </button>
                    </div>
                </div>
                
                <div id="books-table-container">
                    <div class="loading">جاري تحميل الكتب...</div>
                </div>
            </div>
        `;
    }

    renderCategoriesContent() {
        return `
            <div class="form-container">
                <div class="form-header">
                    <h3 class="form-title">إضافة تصنيف جديد</h3>
                </div>
                
                <form id="add-category-form">
                    <div class="form-group">
                        <label class="form-label">اسم التصنيف</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">التصنيفات الفرعية</label>
                        <div id="subcategories-container">
                            <div class="subcategory-input">
                                <input type="text" class="form-control" placeholder="أدخل تصنيف فرعي...">
                                <button type="button" class="btn btn-primary btn-sm" onclick="admin.addSubcategoryInput()">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i> إضافة التصنيف
                    </button>
                </form>
            </div>
            
            <div class="data-table-container">
                <div class="table-header">
                    <h3 class="table-title">قائمة التصنيفات</h3>
                </div>
                
                <div id="categories-table-container">
                    <div class="loading">جاري تحميل التصنيفات...</div>
                </div>
            </div>
        `;
    }

    renderSubmissionsContent() {
        return `
            <div class="data-table-container">
                <div class="table-header">
                    <h3 class="table-title">المساهمات المعلقة</h3>
                    <div class="table-actions">
                        <button class="btn btn-secondary" onclick="admin.loadSubmissions()">
                            <i class="fas fa-refresh"></i> تحديث
                        </button>
                    </div>
                </div>
                
                <div id="submissions-table-container">
                    <div class="loading">جاري تحميل المساهمات...</div>
                </div>
            </div>
        `;
    }

    renderDocumentsContent() {
        return `
            <div class="form-container">
                <div class="form-header">
                    <h3 class="form-title">إضافة وثيقة جديدة</h3>
                </div>
                
                <form id="add-document-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">عنوان الوثيقة</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">التاريخ</label>
                            <input type="date" class="form-control" name="date" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">النوع</label>
                            <select class="form-control" name="type" required>
                                <option value="">اختر النوع</option>
                                <option value="سياسي">سياسي</option>
                                <option value="تاريخي">تاريخي</option>
                                <option value="ثقافي">ثقافي</option>
                                <option value="اقتصادي">اقتصادي</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">التصنيف</label>
                            <select class="form-control" name="category_id" required>
                                <option value="">اختر التصنيف</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">الوصف</label>
                        <textarea class="form-control" name="description" rows="4" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-plus"></i> إضافة الوثيقة
                    </button>
                </form>
            </div>
            
            <div class="data-table-container">
                <div class="table-header">
                    <h3 class="table-title">قائمة الوثائق</h3>
                </div>
                
                <div id="documents-table-container">
                    <div class="loading">جاري تحميل الوثائق...</div>
                </div>
            </div>
        `;
    }

    renderStrategicContent() {
        return `
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-title">القرى الفلسطينية</div>
                        <div class="stat-icon">
                            <i class="fas fa-map-marked-alt"></i>
                        </div>
                    </div>
                    <div class="stat-value" id="strategic-villages">5</div>
                    <div class="stat-description">قرية مع تجارب VR</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-title">أرشيف الثورة</div>
                        <div class="stat-icon">
                            <i class="fas fa-fist-raised"></i>
                        </div>
                    </div>
                    <div class="stat-value" id="revolution-docs">45,000</div>
                    <div class="stat-description">وثيقة ثورية</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-header">
                        <div class="stat-title">تقدم المخطوطات</div>
                        <div class="stat-icon">
                            <i class="fas fa-scroll"></i>
                        </div>
                    </div>
                    <div class="stat-value" id="manuscripts-progress">64%</div>
                    <div class="stat-description">نسبة الرقمنة</div>
                </div>
            </div>
            
            <div class="form-container">
                <div class="form-header">
                    <h3 class="form-title">إدارة المحتوى الاستراتيجي</h3>
                </div>
                
                <p>هذا القسم مخصص لإدارة المحتوى ذو الأولوية الاستراتيجية مثل:</p>
                <ul>
                    <li>القرى الفلسطينية وتجارب العودة الافتراضية</li>
                    <li>أرشيف الثورة الفلسطينية</li>
                    <li>المخطوطات النادرة وعملية الرقمنة</li>
                    <li>تصنيف مستويات السيادة والأهمية السردية</li>
                </ul>
                
                <div class="form-row">
                    <button class="btn btn-primary">
                        <i class="fas fa-plus"></i> إضافة قرية فلسطينية
                    </button>
                    <button class="btn btn-success">
                        <i class="fas fa-upload"></i> رفع وثائق الثورة
                    </button>
                    <button class="btn btn-warning">
                        <i class="fas fa-scroll"></i> إدارة المخطوطات
                    </button>
                </div>
            </div>
        `;
    }

    renderUsersContent() {
        return `
            <div class="data-table-container">
                <div class="table-header">
                    <h3 class="table-title">إدارة المستخدمين</h3>
                    <div class="table-actions">
                        <button class="btn btn-primary">
                            <i class="fas fa-user-plus"></i> إضافة مستخدم
                        </button>
                    </div>
                </div>
                
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="empty-title">نظام إدارة المستخدمين</div>
                    <div class="empty-description">
                        سيتم تطوير هذا القسم لاحقاً لإدارة حسابات المستخدمين المسجلين
                    </div>
                </div>
            </div>
        `;
    }

    renderSettingsContent() {
        return `
            <div class="form-container">
                <div class="form-header">
                    <h3 class="form-title">إعدادات النظام</h3>
                </div>
                
                <form id="settings-form">
                    <div class="form-group">
                        <label class="form-label">اسم المكتبة</label>
                        <input type="text" class="form-control" value="المكتبة الوطنية الرقمية الفلسطينية">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">البريد الإلكتروني</label>
                        <input type="email" class="form-control" value="info@palestinelibrary.ps">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">رقم الهاتف</label>
                        <input type="tel" class="form-control" value="+970-2-XXX-XXXX">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">وصف المكتبة</label>
                        <textarea class="form-control" rows="4">مشروع سيادي لحفظ التراث والذاكرة الفلسطينية للأجيال القادمة</textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> حفظ الإعدادات
                    </button>
                </form>
            </div>
        `;
    }

    setupEventListeners() {
        // Form submissions
        document.addEventListener('submit', (e) => {
            if (e.target.id === 'add-book-form') {
                e.preventDefault();
                this.addBook(e.target);
            }
            if (e.target.id === 'add-category-form') {
                e.preventDefault();
                this.addCategory(e.target);
            }
        });

        // Category selection changes
        document.addEventListener('change', (e) => {
            if (e.target.id === 'book-category') {
                this.updateSubcategories(e.target.value, 'book-subcategory');
            }
        });

        // Search functionality
        document.addEventListener('input', (e) => {
            if (e.target.id === 'books-search') {
                // Implement search functionality
            }
        });
    }

    async loadInitialData() {
        await this.loadCategories();
        await this.loadDashboardStats();
        this.populateCategorySelects();
    }

    async loadCategories() {
        try {
            const response = await fetch('/admin/api/categories');
            const result = await response.json();
            
            if (result.success) {
                this.categories = result.data;
                this.renderCategoriesTable();
            }
        } catch (error) {
            console.error('Error loading categories:', error);
        }
    }

    populateCategorySelects() {
        const selects = document.querySelectorAll('select[name="category_id"], #book-category');
        selects.forEach(select => {
            select.innerHTML = `
                <option value="">اختر التصنيف</option>
                ${this.categories.map(cat => `
                    <option value="${cat.id}">${cat.name}</option>
                `).join('')}
            `;
        });
    }

    updateSubcategories(categoryId, targetSelectId) {
        const category = this.categories.find(cat => cat.id == categoryId);
        const targetSelect = document.getElementById(targetSelectId);
        
        if (targetSelect && category) {
            targetSelect.innerHTML = `
                <option value="">اختر التصنيف الفرعي</option>
                ${category.subcategories.map(sub => `
                    <option value="${sub}">${sub}</option>
                `).join('')}
            `;
        }
    }

    async loadDashboardStats() {
        try {
            const [statsResponse, booksResponse, submissionsResponse] = await Promise.all([
                fetch('/api/strategic-stats'),
                fetch('/admin/api/books'),
                fetch('/admin/api/submissions')
            ]);

            const [stats, books, submissions] = await Promise.all([
                statsResponse.json(),
                booksResponse.json(),
                submissionsResponse.json()
            ]);

            if (stats.success) {
                document.getElementById('total-villages').textContent = stats.data.villages.total;
                document.getElementById('digitized-manuscripts').textContent = `${stats.data.manuscripts.digitization_progress}%`;
            }

            if (books.success) {
                document.getElementById('total-books').textContent = books.data.length;
            }

            if (submissions.success) {
                document.getElementById('pending-submissions').textContent = submissions.data.length;
                document.getElementById('submissions-badge').textContent = submissions.data.length;
            }

        } catch (error) {
            console.error('Error loading dashboard stats:', error);
        }
    }

    async loadBooks() {
        try {
            const response = await fetch('/admin/api/books');
            const result = await response.json();
            
            if (result.success) {
                this.renderBooksTable(result.data);
            }
        } catch (error) {
            console.error('Error loading books:', error);
        }
    }

    renderBooksTable(books) {
        const container = document.getElementById('books-table-container');
        
        if (books.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-book"></i>
                    </div>
                    <div class="empty-title">لا توجد كتب</div>
                    <div class="empty-description">ابدأ بإضافة أول كتاب في المكتبة</div>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>العنوان</th>
                        <th>المؤلف</th>
                        <th>السنة</th>
                        <th>التصنيف</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    ${books.map(book => `
                        <tr>
                            <td>${book.title}</td>
                            <td>${book.author}</td>
                            <td>${book.year}</td>
                            <td>${book.category_name || 'غير محدد'}</td>
                            <td>
                                <span class="status-badge status-${book.status}">${book.status}</span>
                            </td>
                            <td class="table-actions-cell">
                                <button class="btn btn-sm btn-secondary" onclick="admin.editBook(${book.id})">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="admin.deleteBook(${book.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    renderCategoriesTable() {
        const container = document.getElementById('categories-table-container');
        
        container.innerHTML = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>اسم التصنيف</th>
                        <th>التصنيفات الفرعية</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.categories.map(category => `
                        <tr>
                            <td>${category.name}</td>
                            <td>
                                ${category.subcategories.map(sub => `
                                    <span class="status-badge status-published">${sub}</span>
                                `).join(' ')}
                            </td>
                            <td class="table-actions-cell">
                                <button class="btn btn-sm btn-secondary">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    async loadSubmissions() {
        try {
            const response = await fetch('/admin/api/submissions');
            const result = await response.json();
            
            if (result.success) {
                this.renderSubmissionsTable(result.data);
            }
        } catch (error) {
            console.error('Error loading submissions:', error);
        }
    }

    renderSubmissionsTable(submissions) {
        const container = document.getElementById('submissions-table-container');
        
        if (submissions.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">
                        <i class="fas fa-inbox"></i>
                    </div>
                    <div class="empty-title">لا توجد مساهمات معلقة</div>
                    <div class="empty-description">جميع المساهمات تمت مراجعتها</div>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <table class="data-table">
                <thead>
                    <tr>
                        <th>العنوان</th>
                        <th>النوع</th>
                        <th>المساهم</th>
                        <th>تاريخ الإرسال</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    ${submissions.map(submission => `
                        <tr>
                            <td>${submission.title}</td>
                            <td>
                                <span class="status-badge status-pending">${submission.type === 'book' ? 'كتاب' : 'وثيقة'}</span>
                            </td>
                            <td>${submission.submitted_by}</td>
                            <td>${new Date(submission.submitted_at).toLocaleDateString('ar-EG')}</td>
                            <td class="table-actions-cell">
                                <button class="btn btn-sm btn-success" onclick="admin.approveSubmission(${submission.id})">
                                    <i class="fas fa-check"></i> قبول
                                </button>
                                <button class="btn btn-sm btn-danger" onclick="admin.rejectSubmission(${submission.id})">
                                    <i class="fas fa-times"></i> رفض
                                </button>
                                <button class="btn btn-sm btn-secondary" onclick="admin.viewSubmission(${submission.id})">
                                    <i class="fas fa-eye"></i> عرض
                                </button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });

        // Show target section
        document.getElementById(sectionName + '-section').classList.add('active');

        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        
        document.querySelector(`[onclick*="${sectionName}"]`).classList.add('active');

        // Update page title
        const titles = {
            dashboard: 'لوحة التحكم الرئيسية',
            books: 'إدارة الكتب',
            categories: 'إدارة التصنيفات',
            submissions: 'المساهمات المعلقة',
            documents: 'إدارة الوثائق',
            strategic: 'المحتوى الاستراتيجي',
            users: 'إدارة المستخدمين',
            settings: 'إعدادات النظام'
        };

        document.getElementById('page-title').textContent = titles[sectionName];

        // Load section data
        switch (sectionName) {
            case 'books':
                this.loadBooks();
                break;
            case 'submissions':
                this.loadSubmissions();
                break;
        }

        this.currentSection = sectionName;
    }

    async addBook(form) {
        const formData = new FormData(form);
        const bookData = Object.fromEntries(formData.entries());

        try {
            const response = await fetch('/admin/api/books', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(bookData)
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('تم إضافة الكتاب بنجاح', 'success');
                form.reset();
                this.loadBooks();
            } else {
                this.showNotification(result.message || 'حدث خطأ في إضافة الكتاب', 'error');
            }
        } catch (error) {
            console.error('Error adding book:', error);
            this.showNotification('حدث خطأ في إضافة الكتاب', 'error');
        }
    }

    async addCategory(form) {
        const formData = new FormData(form);
        const subcategoryInputs = form.querySelectorAll('#subcategories-container input');
        const subcategories = Array.from(subcategoryInputs)
            .map(input => input.value.trim())
            .filter(value => value);

        const categoryData = {
            name: formData.get('name'),
            subcategories: subcategories
        };

        try {
            const response = await fetch('/admin/api/categories', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(categoryData)
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('تم إضافة التصنيف بنجاح', 'success');
                form.reset();
                this.loadCategories();
                this.populateCategorySelects();
            } else {
                this.showNotification(result.message || 'حدث خطأ في إضافة التصنيف', 'error');
            }
        } catch (error) {
            console.error('Error adding category:', error);
            this.showNotification('حدث خطأ في إضافة التصنيف', 'error');
        }
    }

    addSubcategoryInput() {
        const container = document.getElementById('subcategories-container');
        const newInput = document.createElement('div');
        newInput.className = 'subcategory-input';
        newInput.innerHTML = `
            <input type="text" class="form-control" placeholder="أدخل تصنيف فرعي...">
            <button type="button" class="btn btn-danger btn-sm" onclick="this.parentElement.remove()">
                <i class="fas fa-minus"></i>
            </button>
        `;
        container.appendChild(newInput);
    }

    async approveSubmission(submissionId) {
        if (!confirm('هل أنت متأكد من قبول هذه المساهمة؟')) return;

        try {
            const response = await fetch(`/admin/api/submissions/${submissionId}/approve`, {
                method: 'PUT'
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('تم قبول المساهمة ونشرها', 'success');
                this.loadSubmissions();
                this.loadDashboardStats();
            } else {
                this.showNotification(result.message || 'حدث خطأ', 'error');
            }
        } catch (error) {
            console.error('Error approving submission:', error);
            this.showNotification('حدث خطأ في قبول المساهمة', 'error');
        }
    }

    async rejectSubmission(submissionId) {
        if (!confirm('هل أنت متأكد من رفض هذه المساهمة؟')) return;

        try {
            const response = await fetch(`/admin/api/submissions/${submissionId}`, {
                method: 'DELETE'
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('تم رفض المساهمة', 'success');
                this.loadSubmissions();
                this.loadDashboardStats();
            } else {
                this.showNotification(result.message || 'حدث خطأ', 'error');
            }
        } catch (error) {
            console.error('Error rejecting submission:', error);
            this.showNotification('حدث خطأ في رفض المساهمة', 'error');
        }
    }

    viewSubmission(submissionId) {
        // Implement submission viewing modal
        alert('سيتم إضافة نافذة عرض تفاصيل المساهمة قريباً');
    }

    async deleteBook(bookId) {
        if (!confirm('هل أنت متأكد من حذف هذا الكتاب؟')) return;

        try {
            const response = await fetch(`/admin/api/books/${bookId}`, {
                method: 'DELETE'
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('تم حذف الكتاب بنجاح', 'success');
                this.loadBooks();
            } else {
                this.showNotification(result.message || 'حدث خطأ', 'error');
            }
        } catch (error) {
            console.error('Error deleting book:', error);
            this.showNotification('حدث خطأ في حذف الكتاب', 'error');
        }
    }

    editBook(bookId) {
        alert('سيتم إضافة نافذة تحرير الكتاب قريباً');
    }

    async logout() {
        try {
            const response = await fetch('/admin/api/logout', {
                method: 'POST'
            });

            const result = await response.json();

            if (result.success) {
                window.location.href = '/admin/login';
            }
        } catch (error) {
            console.error('Error logging out:', error);
            window.location.href = '/admin/login';
        }
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Initialize admin dashboard
const admin = new AdminDashboard();